# M'lay Service V3.4 — Option gratuite

Cette version retire la dépendance à Google Maps Platform / Places API.

- Carte : OpenStreetMap + Leaflet.
- Recherche externe : OpenStreetMap/Nominatim, centrée sur Toliara.
- Données M'lay dans Firebase : menus, plats, prix, photos, partenaires, publicités, commandes.
- Résultats mixtes : plats M'lay + partenaires M'lay + lieux externes.
- Les résultats externes sont affichés sur la carte M'lay.
- Bouton d'itinéraire : ouverture de Google Maps via URL, sans clé Google Maps Platform.
- Aucun `GOOGLE_MAPS_API_KEY` n'est nécessaire.
- Le secret `FIREBASE_API_KEY` reste utilisé comme dans les versions précédentes.

Note : les services publics OpenStreetMap/Nominatim ont des politiques d'usage et ne doivent pas être considérés comme une infrastructure garantie pour un trafic commercial important. Pour un prototype/faible trafic, cette version évite une clé Google Maps payante.
