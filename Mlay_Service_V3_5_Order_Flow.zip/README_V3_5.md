# M'lay Service V3.5 — Order Flow

Ajouts :
- fiches établissement pour Restaurant / Fast-food / Hôtel / Boutique / Pharmacie ;
- menu avec photo, nom, catégorie, description, prix et lieu/restaurant ;
- bouton Ajouter au panier sur les produits ;
- panier enrichi avec nom du restaurant ;
- étape adresse ;
- étape confirmation ;
- paiement à la livraison ;
- MVola / Orange Money / Airtel Money affichés comme options futures ;
- bouton Commander maintenant ;
- création de commande Firebase avec `paymentMethod: cash` et `paymentStatus: pending` ;
- demande envoyée ensuite aux livreurs disponibles.

Pour les hôtels, la fiche utilise la section `Restaurant / menus de l’hôtel` sans ajouter de réservation de chambre.
