import {auth,db,googleProvider,firebaseConfig} from './firebase-config.js';
import {createUserWithEmailAndPassword,signInWithEmailAndPassword,signInWithPopup,signOut,onAuthStateChanged,sendPasswordResetEmail,updateProfile} from 'https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js';
import {ref,set,get,push,update,remove,onValue,runTransaction} from 'https://www.gstatic.com/firebasejs/12.17.1/firebase-database.js';
const S={user:null,profile:null,partners:{},products:{},posts:{},ads:{},places:{},orders:{},cart:[],merchant:null,order:null,category:'Tous',adminTab:'orders',address:null,qtyPick:{}};
const WALK_SPEED_KMH=4.5;               // vitesse de marche moyenne d'un livreur à pied
const DELIVERY_FEE_MIN=2500;             // tarif plancher (livraison très proche)
const DELIVERY_FEE_MAX=5000;             // tarif plafond (livraison la plus éloignée dans Toliara)
const DELIVERY_FEE_MAX_DISTANCE_KM=3.5;  // distance (aller simple) à partir de laquelle le tarif plafonne
const EVENING_START_HOUR=18;             // à partir de 18h
const EVENING_SURCHARGE=0.25;            // +25% le soir (dans la fourchette 20-30% demandée)

function haversineKm(a,b){
  if(!a||!b||!Number.isFinite(a.lat)||!Number.isFinite(a.lng)||!Number.isFinite(b.lat)||!Number.isFinite(b.lng))return null;
  const R=6371,toRad=x=>x*Math.PI/180;
  const dLat=toRad(b.lat-a.lat),dLng=toRad(b.lng-a.lng);
  const s=Math.sin(dLat/2)**2+Math.cos(toRad(a.lat))*Math.cos(toRad(b.lat))*Math.sin(dLng/2)**2;
  return R*2*Math.atan2(Math.sqrt(s),Math.sqrt(1-s));
}
function isEveningNow(){const h=new Date().getHours();return h>=EVENING_START_HOUR||h<5}
function estimateDelivery(partnerGeo,clientGeo){
  const evening=isEveningNow();
  const distanceKm=haversineKm(partnerGeo,clientGeo);
  if(distanceKm==null){
    // Coordonnées manquantes (adresse ou partenaire non géolocalisé) : estimation moyenne par défaut
    let price=3500; if(evening)price=Math.round(price*(1+EVENING_SURCHARGE)/100)*100;
    return{distanceKm:null,etaMinutes:25,price,evening};
  }
  const ratio=Math.min(1,distanceKm/DELIVERY_FEE_MAX_DISTANCE_KM);
  let price=DELIVERY_FEE_MIN+ratio*(DELIVERY_FEE_MAX-DELIVERY_FEE_MIN);
  if(evening)price*=(1+EVENING_SURCHARGE);
  price=Math.round(price/100)*100; // arrondi à 100 Ar
  const etaMinutes=Math.max(8,Math.round((distanceKm/WALK_SPEED_KMH)*60)+8); // +8 min de marge (récupération/remise)
  return{distanceKm,etaMinutes,price,evening};
}
const $=id=>document.getElementById(id), money=n=>new Intl.NumberFormat('fr-FR').format(Number(n||0))+' Ar', esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function addToCart(partnerId,productId,qtyToAdd=1){
  const p=(S.products[partnerId]||{})[productId];
  if(!p||p.available===false)return false;
  const row=S.cart.find(x=>x.partnerId===partnerId&&x.productId===productId);
  if(row)row.qty+=qtyToAdd;
  else S.cart.push({partnerId,productId,name:p.name,price:+p.price,qty:qtyToAdd,restaurantName:S.partners?.[partnerId]?.name||'Partenaire',restaurantAddress:S.partners?.[partnerId]?.address||'Toliara'});
  return true;
}
function pickQty(id,d){S.qtyPick[id]=Math.max(1,(S.qtyPick[id]||1)+d)}
let maps={}; let mapLayers={}; let searchTimer=null; const toast=m=>{const e=$('toast');e.textContent=m;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2400)};
function go(n){if(!S.user&&!['auth','splash'].includes(n))n='auth'; if(n==='admin'&&S.profile?.role!=='admin')n='profile';if(n==='driver'&&S.profile?.role!=='driver')n='profile';if(n==='partner'&&S.profile?.role!=='partner')n='profile';document.querySelectorAll('.screen').forEach(x=>x.classList.toggle('active',x.dataset.screen===n));setTimeout(()=>render(n),30)}
document.addEventListener('click',e=>{const b=e.target.closest('[data-go]');if(b)go(b.dataset.go)});document.querySelector('[data-action=start]').onclick=()=>go(S.user?'home':'auth');
function configured(){return firebaseConfig.apiKey&&!firebaseConfig.apiKey.includes('__FIREBASE_API_KEY__')}
async function profile(user,extra={}){const r=ref(db,'users/'+user.uid),s=await get(r);if(!s.exists())await set(r,{uid:user.uid,name:extra.name||user.displayName||'Utilisateur',email:user.email||'',phone:extra.phone||'',role:'client',status:'active',createdAt:Date.now()});S.profile=(await get(r)).val()}
function roleRoute(){go(S.profile?.role==='admin'?'admin':S.profile?.role==='driver'?'driver':S.profile?.role==='partner'?'partner':'home')}
document.querySelectorAll('[data-auth-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-auth-tab]').forEach(x=>x.classList.toggle('active',x===b));$('loginForm').classList.toggle('hidden',b.dataset.authTab!=='login');$('registerForm').classList.toggle('hidden',b.dataset.authTab==='login')});
$('loginForm').onsubmit=async e=>{e.preventDefault();try{await signInWithEmailAndPassword(auth,$('loginId').value,$('loginPassword').value)}catch(x){toast('Connexion impossible : '+x.code)}};
$('registerForm').onsubmit=async e=>{e.preventDefault();try{const c=await createUserWithEmailAndPassword(auth,$('regEmail').value,$('regPassword').value);await updateProfile(c.user,{displayName:$('regName').value});await profile(c.user,{name:$('regName').value,phone:$('regPhone').value});roleRoute()}catch(x){toast('Inscription impossible : '+x.code)}};
$('googleLoginBtn').onclick=async()=>{try{const c=await signInWithPopup(auth,googleProvider);await profile(c.user);roleRoute()}catch(x){toast('Google : '+x.code)}};$('forgotPasswordBtn').onclick=async()=>{if(!$('loginId').value)return toast('Entre ton e-mail');await sendPasswordResetEmail(auth,$('loginId').value);toast('E-mail envoyé')};$('logoutBtn').onclick=()=>signOut(auth);
function listen(){[['partners','partners'],['products','products'],['posts','posts'],['ads','ads'],['places','places'],['orders','orders']].forEach(([p,k])=>onValue(ref(db,p),s=>{S[k]=s.val()||{};rerender()}))}function rerender(){const n=document.querySelector('.screen.active')?.dataset.screen;if(n)render(n)}
onAuthStateChanged(auth,async u=>{S.user=u;if(!u)return go('auth');await profile(u);listen();roleRoute()});
function render(n){({home:renderHome,merchant:renderMerchant,cart:renderCart,address:initAddressMap,checkout:()=>summary('checkoutRecap'),orders:renderOrders,tracking:renderTracking,profile:renderProfile,driver:renderDriver,partner:renderPartner,admin:renderAdmin}[n]||(()=>{}))()}
function partnerArr(){return Object.entries(S.partners).map(([id,v])=>({id,...v})).filter(x=>x.status!=='suspended')}



const TOLIARA_CENTER={lat:-23.3516,lng:43.6855};

async function searchOpenStreetMap(queryText){
  const query=String(queryText||"").trim();
  if(query.length<2){S.osmResults=[];return []}
  S.osmBusy=true;
  try{
    // Free external place search. Toliara is appended to bias results to the service city.
    const url=`https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=12&countrycodes=mg&q=${encodeURIComponent(query+" Toliara Madagascar")}`;
    const r=await fetch(url,{headers:{"Accept":"application/json","Accept-Language":"fr"}});
    if(!r.ok) throw new Error("Recherche de lieux indisponible");
    const rows=await r.json();
    S.osmResults=(rows||[]).map(x=>({
      id:String(x.place_id||x.osm_id||""),
      name:(x.name||String(x.display_name||"").split(",")[0]||"Lieu"),
      address:x.display_name||"",
      lat:Number(x.lat),lng:Number(x.lon),
      type:x.type||x.category||"",
      source:"osm"
    })).filter(x=>Number.isFinite(x.lat)&&Number.isFinite(x.lng));
    S.osmQuery=query;
    return S.osmResults;
  }catch(e){
    console.warn("OSM search:",e); S.osmResults=[]; return [];
  }finally{S.osmBusy=false}
}

function internalProductMatches(q){
  const out=[];
  Object.entries(S.products||{}).forEach(([partnerId,products])=>{
    const partner=S.partners?.[partnerId];
    Object.entries(products||{}).forEach(([productId,p])=>{
      if(p.available===false)return;
      const hay=`${p.name||""} ${p.description||""} ${p.category||""} ${partner?.name||""} ${partner?.address||""}`.toLowerCase();
      if(!q||hay.includes(q)) out.push({partnerId,productId,partnerName:partner?.name||"Partenaire",partnerAddress:partner?.address||"",...p});
    });
  });
  return out;
}
function internalPartnerMatches(q){
  return partnerArr().filter(p=>!q||`${p.name||""} ${p.category||""} ${p.address||""}`.toLowerCase().includes(q));
}
function mergedSuggestionHtml(q){
  const products=internalProductMatches(q).slice(0,5);
  const partners=internalPartnerMatches(q).slice(0,4);
  const places=(S.osmResults||[]).slice(0,6);
  let html="";
  if(products.length) html+=`<div class="suggest-group"><span>PLATS M'LAY</span>${products.map(x=>`
    <button class="suggest-row" data-suggest-product="${x.partnerId}|${x.productId}">
      ${x.imageUrl?`<img src="${esc(x.imageUrl)}">`:`<i>🍽️</i>`}
      <div><b>${esc(x.name)}</b><small>${esc(x.partnerName)} • ${money(x.price)}</small></div><em>Ajouter</em>
    </button>`).join("")}</div>`;
  if(partners.length) html+=`<div class="suggest-group"><span>PARTENAIRES M'LAY</span>${partners.map(p=>`
    <button class="suggest-row" data-suggest-partner="${p.id}">
      ${p.logoUrl?`<img src="${esc(p.logoUrl)}">`:`<i>🏪</i>`}
      <div><b>${esc(p.name)}</b><small>${esc(p.category||"Restaurant")} • ${esc(p.address||"Toliara")}</small></div><em>Menu</em>
    </button>`).join("")}</div>`;
  if(places.length) html+=`<div class="suggest-group"><span>LIEUX OPENSTREETMAP • TOLIARA</span>${places.map((p,i)=>`
    <button class="suggest-row osm-result" data-osm-result="${i}">
      <i>📍</i><div><b>${esc(p.name)}</b><small>${esc(p.address||"Toliara")}</small></div><em>Carte</em>
    </button>`).join("")}</div>`;
  if(!html) html=`<div class="suggest-empty">${S.osmBusy?"Recherche des lieux…":"Aucun résultat pour le moment."}</div>`;
  return html;
}
function showSearchSuggestions(){
  const box=$("searchSuggestions"); if(!box)return;
  const q=($("searchInput")?.value||"").trim().toLowerCase();
  if(!q){box.classList.add("hidden");box.innerHTML="";return}
  box.innerHTML=mergedSuggestionHtml(q); box.classList.remove("hidden");
  box.querySelectorAll("[data-suggest-product]").forEach(b=>b.onclick=()=>{
    const [partnerId,productId]=b.dataset.suggestProduct.split("|");
    if(addToCart(partnerId,productId,1)){badges();toast("Ajouté au panier")}
    showSearchSuggestions();
  });
  box.querySelectorAll("[data-suggest-partner]").forEach(b=>b.onclick=()=>{S.merchant=b.dataset.suggestPartner;box.classList.add("hidden");go("merchant")});
  box.querySelectorAll("[data-osm-result]").forEach(b=>b.onclick=()=>{focusOsmResult(Number(b.dataset.osmResult));box.classList.add("hidden")});
}
async function searchEverything(){
  const raw=($("searchInput")?.value||"").trim(),q=raw.toLowerCase();
  if($("clearSearchBtn"))$("clearSearchBtn").classList.toggle("hidden",!raw);
  renderHomeBase(q); showSearchSuggestions();
  if(searchTimer)clearTimeout(searchTimer);
  searchTimer=setTimeout(async()=>{await searchOpenStreetMap(raw);showSearchSuggestions();renderRestaurantMaps()},650);
}
function renderOsmResultsOnMap(id){
  const el=$(id);if(!el||!window.L)return;
  const map=leaflet(id,[TOLIARA_CENTER.lat,TOLIARA_CENTER.lng]); map.invalidateSize();
  if(!mapLayers[id])mapLayers[id]=L.layerGroup().addTo(map);
  clearMapLayer(id);

  const points=[];
  partnerArr().forEach(p=>{
    const g=partnerCoords(p);if(!g)return;points.push([g.lat,g.lng]);
    L.marker([g.lat,g.lng]).addTo(mapLayers[id]).bindPopup(partnerPopup(p));
  });
  (S.osmResults||[]).forEach((p,i)=>{
    points.push([p.lat,p.lng]);
    L.marker([p.lat,p.lng]).addTo(mapLayers[id]).bindPopup(
      `<div class="map-popup"><b>${esc(p.name)}</b><small>OpenStreetMap</small><p>${esc(p.address)}</p><div><button onclick="window.mlayOsmResult(${i})">Centrer</button><button onclick="window.mlayOsmGoogleMaps(${i})">Itinéraire Google Maps</button></div></div>`
    );
  });
  if(points.length){
    const bounds=L.latLngBounds(points);if(bounds.isValid())map.fitBounds(bounds.pad(.15),{maxZoom:16});
  }else map.setView([TOLIARA_CENTER.lat,TOLIARA_CENTER.lng],13);
}
function renderRestaurantMaps(){
  renderOsmResultsOnMap("clientRestaurantMap");
  renderOsmResultsOnMap("clientRestaurantMapMobile");
}
function focusOsmResult(i){
  const p=S.osmResults?.[i];if(!p)return;
  const id=window.matchMedia("(max-width:760px)").matches?"clientRestaurantMapMobile":"clientRestaurantMap";
  const map=leaflet(id,[p.lat,p.lng]);map.setView([p.lat,p.lng],17);
  L.popup().setLatLng([p.lat,p.lng]).setContent(`<b>${esc(p.name)}</b><br>${esc(p.address)}`).openOn(map);
  document.getElementById(id)?.scrollIntoView({behavior:"smooth",block:"center"});
}
window.mlayOsmResult=focusOsmResult;
window.mlayOsmGoogleMaps=i=>{
  const p=S.osmResults?.[i];if(!p)return;
  window.open(`https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}`,"_blank");
};

function renderHomeBase(qOverride=null){
  $('homeAvatar').textContent=(S.profile?.name||'M')[0].toUpperCase();

  const cats=['Tous',...new Set(partnerArr().map(x=>x.category).filter(Boolean))];
  $('categoryRow').innerHTML=cats.map(c=>`<button class="${S.category===c?'active':''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
  document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{S.category=b.dataset.cat;renderHome()});

  const q=qOverride!==null?qOverride:($('searchInput')?.value||'').toLowerCase();

  const partners=partnerArr().filter(p=>
    (S.category==='Tous'||p.category===S.category) &&
    (!q||(`${p.name||''} ${p.category||''} ${p.address||''}`).toLowerCase().includes(q))
  );

  $('partnerCount').textContent=`${partners.length} disponible${partners.length>1?'s':''}`;

  $('partnerList').innerHTML=partners.map(p=>`
    <article class="partner-card">
      <button class="partner-main" data-p="${p.id}">
        ${p.logoUrl?`<img src="${esc(p.logoUrl)}" alt="${esc(p.name)}">`:`<span class="partner-placeholder">🏪</span>`}
        <div class="partner-copy">
          <b>${esc(p.name)}</b>
          <p>${esc(p.category||'Commerce')}</p>
          <small>📍 ${esc(p.address||'Toliara')}</small>
        </div>
        <span class="partner-arrow">›</span>
      </button>
      <div class="partner-actions">
        <button data-p="${p.id}">Voir le menu</button>
        <button data-map-focus="${p.id}">Carte</button>
        <button data-google-partner="${p.id}">Google Maps</button>
      </div>
    </article>
  `).join('')||'<p class="muted">Aucun partenaire.</p>';

  document.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{S.merchant=b.dataset.p;go('merchant')});
  document.querySelectorAll('[data-map-focus]').forEach(b=>b.onclick=()=>focusPartnerOnMap(b.dataset.mapFocus));
  document.querySelectorAll('[data-google-partner]').forEach(b=>b.onclick=()=>openPartnerGoogleMaps(b.dataset.googlePartner));

  const ads=Object.values(S.ads||{}).filter(x=>x.active!==false);
  $('adBanner').innerHTML=ads.length?ads.slice(0,4).map(a=>`
    <article class="ad-card">
      ${a.imageUrl?`<img src="${esc(a.imageUrl)}" alt="">`:`<div class="ad-placeholder">PUB</div>`}
      <div class="ad-content">
        <span>PUBLICITÉ</span>
        <b>${esc(a.title||'Offre M’lay')}</b>
        <p>${esc(a.text||'')}</p>
      </div>
    </article>
  `).join(''):`<article class="ad-card default-ad">
      <div class="ad-placeholder">M'LAY</div>
      <div class="ad-content"><span>ESPACE PUBLICITAIRE</span><b>Votre publicité ici</b><p>Les publicités créées par l’administrateur apparaîtront dans cette zone.</p></div>
    </article>`;

  let allProducts=[];
  Object.entries(S.products||{}).forEach(([partnerId,products])=>{
    const partner=S.partners?.[partnerId];
    Object.entries(products||{}).forEach(([productId,p])=>{
      if(p.available===false)return;
      if(q && !(`${p.name||''} ${p.description||''} ${partner?.name||''}`).toLowerCase().includes(q)) return;
      allProducts.push({partnerId,productId,partnerName:partner?.name||'Partenaire',...p});
    });
  });

  $('allMenuList').innerHTML=allProducts.length?allProducts.slice(0,20).map(x=>{const qk=x.partnerId+'|'+x.productId,q=S.qtyPick[qk]||1;return`
    <article class="product-card discover-product">
      ${x.imageUrl?`<img src="${esc(x.imageUrl)}" alt="${esc(x.name)}">`:'<span class="product-placeholder">🍽️</span>'}
      <div>
        <b>${esc(x.name)}</b>
        <small class="restaurant-name">${esc(x.partnerName)}</small>
        <p>${esc(x.description||'')}</p>
        <strong>${money(x.price)}</strong>
      </div>
      <div class="qty-picker">
        <button data-qdec="${qk}">−</button><b>${q}</b><button data-qinc="${qk}">+</button>
      </div>
      <button class="add" data-home-add="${qk}">Ajouter</button>
    </article>`}).join(''):'<div class="empty-menu"><span>🍽️</span><b>Aucun menu publié pour le moment</b><p>L’admin ou le partenaire peut ajouter des menus depuis son espace.</p></div>';

  document.querySelectorAll('#allMenuList [data-qdec]').forEach(b=>b.onclick=()=>{pickQty(b.dataset.qdec,-1);renderHome()});
  document.querySelectorAll('#allMenuList [data-qinc]').forEach(b=>b.onclick=()=>{pickQty(b.dataset.qinc,1);renderHome()});
  document.querySelectorAll('[data-home-add]').forEach(b=>b.onclick=()=>{
    const [partnerId,productId]=b.dataset.homeAdd.split('|'),q=S.qtyPick[b.dataset.homeAdd]||1;
    if(addToCart(partnerId,productId,q)){S.qtyPick[b.dataset.homeAdd]=1;badges();renderHome();toast('Ajouté au panier')}
  });

  const posts=Object.values(S.posts||{}).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));
  $('publicFeed').innerHTML=posts.slice(0,10).map(p=>`
    <article class="post-card">
      ${p.imageUrl?`<img src="${esc(p.imageUrl)}">`:''}
      <div><b>${esc(p.title)}</b><p>${esc(p.text||'')}</p></div>
    </article>
  `).join('')||'<p class="muted">Aucune publication.</p>';

  const count=S.cart.reduce((s,x)=>s+x.qty,0);
  if($('homeCartCount')) $('homeCartCount').textContent=`${count} article${count>1?'s':''}`;
  if($('desktopCartCount')) $('desktopCartCount').textContent=`${count} article${count>1?'s':''}`;

  if($('showAllMenusBtn')) $('showAllMenusBtn').onclick=()=>document.getElementById('allMenusSection')?.scrollIntoView({behavior:'smooth'});
  badges();
  
}

function renderHome(){
  renderHomeBase();
  setTimeout(renderGoogleResultsOnMaps,100);
}
$('searchInput').oninput=searchEverything;
if($("clearSearchBtn")) $("clearSearchBtn").onclick=()=>{
  $("searchInput").value="";
  S.osmResults=[];S.osmQuery="";
  $("clearSearchBtn").classList.add("hidden");
  $("searchSuggestions").classList.add("hidden");
  renderHome();
};
document.addEventListener("click",e=>{
  if(!e.target.closest(".search-wrap") && $("searchSuggestions")) $("searchSuggestions").classList.add("hidden");
});



function partnerCoords(p){
  const lat=Number(p?.lat ?? p?.latitude), lng=Number(p?.lng ?? p?.longitude);
  return Number.isFinite(lat)&&Number.isFinite(lng)&&lat!==0&&lng!==0 ? {lat,lng}:null;
}
function clearMapLayer(id){
  if(mapLayers[id]){
    try{mapLayers[id].clearLayers()}catch{}
  }
}
function partnerPopup(p){
  return `<div class="map-popup"><b>${esc(p.name)}</b><small>${esc(p.category||'Partenaire')}</small><p>${esc(p.address||'Toliara')}</p><div><button onclick="window.mlayOpenPartner('${p.id}')">Voir le menu</button><button onclick="window.mlayOpenPartnerMaps('${p.id}')">Google Maps</button></div></div>`;
}
function renderOneRestaurantMap(id){
  const el=$(id); if(!el||!window.L)return;
  const map=leaflet(id,[-23.3516,43.6855]);
  map.invalidateSize();

  if(!mapLayers[id]) mapLayers[id]=L.layerGroup().addTo(map);
  clearMapLayer(id);

  const partners=partnerArr().filter(p=>partnerCoords(p));
  partners.forEach(p=>{
    const g=partnerCoords(p);
    const marker=L.marker([g.lat,g.lng]).addTo(mapLayers[id]);
    marker.bindPopup(partnerPopup(p));
    marker.on('dblclick',()=>{S.merchant=p.id;go('merchant')});
  });

  if(partners.length){
    const bounds=L.latLngBounds(partners.map(p=>[partnerCoords(p).lat,partnerCoords(p).lng]));
    if(bounds.isValid()) map.fitBounds(bounds.pad(.18),{maxZoom:15});
  }
}

window.mlayOpenPartner=id=>{S.merchant=id;go('merchant')};
window.mlayOpenPartnerMaps=id=>openPartnerGoogleMaps(id);

function focusPartnerOnMap(id){
  const p=S.partners[id],g=partnerCoords(p);
  if(!g)return toast("La position de ce partenaire n'est pas encore enregistrée.");
  const target=window.matchMedia('(max-width: 760px)').matches?'clientRestaurantMapMobile':'clientRestaurantMap';
  const m=leaflet(target,[g.lat,g.lng]);m.setView([g.lat,g.lng],17);
  L.popup().setLatLng([g.lat,g.lng]).setContent(partnerPopup({id,...p})).openOn(m);
  document.getElementById(target)?.scrollIntoView({behavior:'smooth',block:'center'});
}
function openPartnerGoogleMaps(id){
  const p=S.partners[id],g=partnerCoords(p);
  if(g) return openGoogle(g);
  if(p?.address){
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(p.name+' '+p.address+' Toliara')}`,'_blank');
  } else toast("Adresse indisponible.");
}
function locateClientOnMap(){
  if(!navigator.geolocation)return toast("Géolocalisation indisponible");
  navigator.geolocation.getCurrentPosition(pos=>{
    const id=window.matchMedia("(max-width:760px)").matches?"clientRestaurantMapMobile":"clientRestaurantMap";
    const map=leaflet(id,[pos.coords.latitude,pos.coords.longitude]);
    map.setView([pos.coords.latitude,pos.coords.longitude],15);
    L.circleMarker([pos.coords.latitude,pos.coords.longitude],{radius:8,weight:3}).addTo(map).bindPopup("Vous êtes ici").openPopup();
  },()=>toast("Impossible d’obtenir votre position."));
}
$('clientLocateBtn') && ($('clientLocateBtn').onclick=locateClientOnMap);
$('clientLocateBtnMobile') && ($('clientLocateBtnMobile').onclick=locateClientOnMap);



function establishmentIcon(category=""){
  const c=String(category).toLowerCase();
  if(c.includes("hotel")||c.includes("hôtel"))return "🏨";
  if(c.includes("fast"))return "🍔";
  if(c.includes("pharma"))return "💊";
  if(c.includes("boutique"))return "🛍️";
  return "🍽️";
}
function establishmentMenuTitle(category=""){
  const c=String(category).toLowerCase();
  if(c.includes("hotel")||c.includes("hôtel"))return "Restaurant / menus de l’hôtel";
  if(c.includes("fast"))return "Menu fast-food";
  if(c.includes("pharma"))return "Produits disponibles";
  if(c.includes("boutique"))return "Produits de la boutique";
  return "Menu du restaurant";
}
function renderMerchant(){
  const p=S.partners[S.merchant];if(!p)return;

  $('merchantName').textContent=p.name;
  $('merchantHeroName').textContent=p.name;
  $('merchantMeta').textContent=(p.category||'Établissement')+' · '+(p.address||'Toliara');
  $('merchantTypeChip').textContent=p.category||"Partenaire M'lay";
  $('merchantHeroIcon').textContent=establishmentIcon(p.category);
  $('merchantMenuTitle').textContent=establishmentMenuTitle(p.category);
  $('merchantLocationText').textContent=p.address||'Toliara';
  $('merchantHoursText').textContent=p.hours||p.openingHours||'Horaires non renseignés';
  $('merchantOpenStatus').textContent=p.closed===true?'Fermé':'Ouvert';
  $('merchantOpenStatus').classList.toggle('closed',p.closed===true);
  $('merchantDescription').innerHTML=p.description?`<p>${esc(p.description)}</p>`:'';

  const prods=Object.entries(S.products[S.merchant]||{})
    .map(([id,v])=>({id,...v}))
    .filter(x=>x.available!==false);

  const prodGroups=groupProducts(prods.map(x=>[x.id,x]));
  $('productList').innerHTML=prods.length?Object.entries(prodGroups).map(([cat,items])=>`
    <div class="menu-group">
      <h4 class="menu-group-title">${esc(cat)}</h4>
      ${items.map(([,x])=>{const q=S.qtyPick[x.id]||1;return`
        <article class="product-card menu-product">
          ${x.imageUrl?`<img src="${esc(x.imageUrl)}" alt="${esc(x.name)}">`:'<span class="product-placeholder">🍽️</span>'}
          <div class="menu-product-copy">
            <b>${esc(x.name)}</b>
            ${x.tag?`<span class="dish-tag dish-tag-${x.tag}">${menuTagLabel(x.tag)}</span>`:''}
            <p>${esc(x.description||'')}</p>
            <div class="product-location">📍 ${esc(p.name)} • ${esc(p.address||'Toliara')}</div>
            <strong>${money(x.price)}</strong>
          </div>
          <div class="menu-add-controls">
            <div class="qty-picker">
              <button data-qdec="${x.id}">−</button><b>${q}</b><button data-qinc="${x.id}">+</button>
            </div>
            <button class="add" data-add="${x.id}">Ajouter</button>
          </div>
        </article>`}).join('')}
    </div>`).join(''):`<div class="empty-menu"><span>🍽️</span><b>Aucun menu disponible</b><p>L’établissement n’a pas encore publié de produit.</p></div>`;

  document.querySelectorAll('[data-qdec]').forEach(b=>b.onclick=()=>{pickQty(b.dataset.qdec,-1);renderMerchant()});
  document.querySelectorAll('[data-qinc]').forEach(b=>b.onclick=()=>{pickQty(b.dataset.qinc,1);renderMerchant()});
  document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{
    const q=S.qtyPick[b.dataset.add]||1;
    if(addToCart(S.merchant,b.dataset.add,q)){S.qtyPick[b.dataset.add]=1;badges();renderMerchant();toast(`${q} article${q>1?'s':''} ajouté${q>1?'s':''} au panier`)}
  });

  const g=partnerCoords(p);
  $('merchantGoogleMapsBtn').onclick=()=>openPartnerGoogleMaps(S.merchant);
  setTimeout(()=>{
    const el=$('merchantMiniMap');if(!el||!window.L)return;
    const m=leaflet('merchantMiniMap',g?[g.lat,g.lng]:[-23.3516,43.6855]);m.invalidateSize();
    if(mapLayers.merchantMiniMap)mapLayers.merchantMiniMap.clearLayers();
    else mapLayers.merchantMiniMap=L.layerGroup().addTo(m);
    if(g){
      L.marker([g.lat,g.lng]).addTo(mapLayers.merchantMiniMap).bindPopup(esc(p.name)).openPopup();
      m.setView([g.lat,g.lng],16);
    }
  },80);
}
function badges(){
  const n=S.cart.reduce((a,x)=>a+x.qty,0);
  if($('navCartBadge')){$('navCartBadge').textContent=n;$('navCartBadge').classList.toggle('hidden',!n)}
  if($('merchantCartBadge')){$('merchantCartBadge').textContent=n;$('merchantCartBadge').classList.toggle('hidden',!n)}
  if($('floatingCartText'))$('floatingCartText').textContent=`${n} article${n>1?'s':''}`;
  if($('homeCartCount'))$('homeCartCount').textContent=`${n} article${n>1?'s':''}`;
  if($('desktopCartCount'))$('desktopCartCount').textContent=`${n} article${n>1?'s':''}`;
}
function cartGroups(){const g={};S.cart.forEach(x=>{(g[x.partnerId]=g[x.partnerId]||[]).push(x)});return g}
function totals(){
  const groups=cartGroups();let sub=0,del=0;
  const clientGeo=S.address?.geo||null;
  const baskets=Object.entries(groups).map(([partnerId,items])=>{
    const s=items.reduce((a,x)=>a+x.qty*x.price,0);
    const partner=S.partners?.[partnerId];
    const partnerGeo=partnerCoords(partner);
    const est=s?estimateDelivery(partnerGeo,clientGeo):{distanceKm:null,etaMinutes:0,price:0,evening:false};
    sub+=s;del+=est.price;
    return{partnerId,items,sub:s,del:est.price,total:s+est.price,name:partner?.name||items[0]?.restaurantName||'Restaurant',distanceKm:est.distanceKm,etaMinutes:est.etaMinutes,evening:est.evening};
  });
  return{sub,del,total:sub+del,baskets};
}
function basketDeliveryLine(bk){
  if(bk.distanceKm!=null)return`${bk.distanceKm.toFixed(1)} km · ~${bk.etaMinutes} min à pied${bk.evening?' · tarif soir':''}`;
  return"Distance estimée après le choix de l'adresse";
}
function summary(id){
  const t=totals();
  const basketLines=t.baskets.map(bk=>
    `<div class="summary-line"><span>Livraison — ${esc(bk.name)}<br><small class="muted">${basketDeliveryLine(bk)}</small></span><b>${money(bk.del)}</b></div>`
  ).join('');
  $(id).innerHTML=(t.baskets.length>1?`<div class="summary-line"><span>Paniers (${t.baskets.length} restaurants)</span><b></b></div>`:'')+
    `<div class="summary-line"><span>Sous-total articles</span><b>${money(t.sub)}</b></div>
     ${basketLines}
     <div class="summary-line total"><span>Total à payer</span><b>${money(t.total)}</b></div>`;
}

function renderCart(){
  const t=totals();
  $('checkoutBtn').disabled=!S.cart.length;
  $('cartContent').innerHTML=t.baskets.length?t.baskets.map(bk=>`
    <div class="basket-card">
      <div class="basket-header">
        <span>🧺 Panier • ${esc(bk.name)}</span>
        <small>Livraison ${money(bk.del)} · ${basketDeliveryLine(bk)}</small>
      </div>
      ${bk.items.map(x=>`
        <article class="cart-row">
          <div class="cart-product">
            <div class="cart-icon">🍽️</div>
            <div>
              <b>${esc(x.name)}</b>
              <p>${money(x.price)} × ${x.qty}</p>
            </div>
          </div>
          <div class="qty">
            <button data-minus="${x.partnerId}|${x.productId}">−</button>
            <b>${x.qty}</b>
            <button data-plus="${x.partnerId}|${x.productId}">+</button>
          </div>
        </article>`).join('')}
      <div class="basket-subtotal"><span>Sous-total panier</span><b>${money(bk.total)}</b></div>
    </div>`).join(''):'<div class="empty-menu"><span>🛒</span><b>Votre panier est vide</b><p>Ajoutez un plat ou un produit avant de commander.</p></div>';

  document.querySelectorAll('[data-minus]').forEach(b=>b.onclick=()=>qty(b.dataset.minus,-1));
  document.querySelectorAll('[data-plus]').forEach(b=>b.onclick=()=>qty(b.dataset.plus,1));
  summary('cartSummary');badges();
}
function qty(k,d){const[a,b]=k.split('|'),x=S.cart.find(y=>y.partnerId===a&&y.productId===b);if(!x)return;x.qty+=d;if(x.qty<=0)S.cart=S.cart.filter(y=>y!==x);renderCart();badges()}
function leaflet(id,center=[-23.3516,43.6855]){if(maps[id])return maps[id];const m=L.map(id).setView(center,13);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(m);maps[id]=m;return m}
function initAddressMap(){setTimeout(()=>{const m=leaflet('addressMap');m.invalidateSize();m.off('click').on('click',e=>{S.address={...(S.address||{}),geo:{lat:e.latlng.lat,lng:e.latlng.lng}};L.marker(e.latlng).addTo(m)})},80)}$('geoBtn').onclick=()=>navigator.geolocation?.getCurrentPosition(p=>{S.address={...(S.address||{}),geo:{lat:p.coords.latitude,lng:p.coords.longitude}};const m=leaflet('addressMap',[p.coords.latitude,p.coords.longitude]);m.setView([p.coords.latitude,p.coords.longitude],16);L.marker([p.coords.latitude,p.coords.longitude]).addTo(m)});$('addressForm').onsubmit=e=>{e.preventDefault();S.address={...(S.address||{}),label:$('addressLabel').value,text:$('addressText').value,note:$('addressNote').value};go('checkout')};
$('placeOrderBtn').onclick=async()=>{
  if(!S.address)return toast('Adresse manquante');
  const t=totals();if(!t.baskets.length)return;
  const writes={},ids=[];
  t.baskets.forEach(bk=>{
    const k=push(ref(db,'orders')).key;ids.push(k);
    writes['orders/'+k]={id:k,clientId:S.user.uid,clientName:S.profile.name,partnerId:bk.partnerId,restaurantName:bk.name,items:bk.items,address:S.address,subtotal:bk.sub,deliveryFee:bk.del,distanceKm:bk.distanceKm,etaMinutes:bk.etaMinutes,evening:bk.evening,total:bk.total,status:'pending_restaurant',driverId:null,createdAt:Date.now()};
  });
  await update(ref(db),writes);
  S.order=ids[0];S.cart=[];badges();
  toast(ids.length>1?`${ids.length} commandes envoyées (1 par restaurant)`:'Commande envoyée');
  go(ids.length>1?'orders':'tracking');
};
function orderArr(){return Object.entries(S.orders).map(([id,v])=>({id,...v}))}function label(s){return({pending_restaurant:'Nouvelle commande — en attente du restaurant',preparing:'En préparation',searching_driver:'Recherche livreur',driver_assigned:'Livreur en route vers le restaurant',on_the_way:'En route vers vous',delivered:'Livrée',cancelled:'Annulée'})[s]||s}function renderOrders(){const a=orderArr().filter(x=>x.clientId===S.user.uid).sort((a,b)=>b.createdAt-a.createdAt);$('ordersList').innerHTML=a.map(o=>`<button class="order-card" data-o="${o.id}"><b>${o.id.slice(-8)}</b><p>${label(o.status)} · ${money(o.total)}</p></button>`).join('')||'<p class="muted">Aucune commande.</p>';document.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>{S.order=b.dataset.o;go('tracking')})}
function activeOrder(){return S.orders[S.order]||orderArr().filter(x=>x.clientId===S.user?.uid)[0]}function renderTracking(){const o=activeOrder();if(!o)return;$('trackingInfo').innerHTML=`<div class="card"><b>${o.id.slice(-8)}</b><p>${label(o.status)} · ${money(o.total)}</p>${o.distanceKm!=null?`<p>${o.distanceKm.toFixed(1)} km · ~${o.etaMinutes} min à pied${o.evening?' · tarif soir':''}</p>`:''}${o.driverName?`<p>Livreur : ${esc(o.driverName)}</p>`:''}</div>`;const steps=['pending_restaurant','preparing','searching_driver','driver_assigned','on_the_way','delivered'],i=steps.indexOf(o.status);$('timeline').innerHTML=steps.map((s,j)=>`<div class="timeline-step ${j<=i?'done':''}">${label(s)}</div>`).join('');setTimeout(()=>{const m=leaflet('trackingMap');m.invalidateSize();if(o.address?.geo)L.marker([o.address.geo.lat,o.address.geo.lng]).addTo(m).bindPopup('Destination')},80);$('clientGoogleMapsBtn').onclick=()=>openGoogle(o.address?.geo)}function openGoogle(g,origin){if(!g)return toast('Coordonnées indisponibles');const d=`${g.lat},${g.lng}`,url=origin?`https://www.google.com/maps/dir/?api=1&origin=${origin.lat},${origin.lng}&destination=${d}&travelmode=driving`:`https://www.google.com/maps/search/?api=1&query=${d}`;window.open(url,'_blank')}
function renderProfile(){$('profileName').textContent=S.profile.name;$('profileContact').textContent=(S.profile.email||'')+' · '+(S.profile.phone||'');$('profileAvatar').textContent=(S.profile.name||'M')[0];$('profileRoleButton').classList.toggle('hidden',S.profile.role==='client');$('profileRoleButton').onclick=()=>go(S.profile.role==='admin'?'admin':S.profile.role==='driver'?'driver':'partner')}
$('driverOnline').onchange=e=>set(ref(db,'driverStatus/'+S.user.uid),{online:e.target.checked,updatedAt:Date.now()});async function claim(id){const r=await runTransaction(ref(db,'orders/'+id),o=>{if(!o||o.driverId||o.status!=='searching_driver')return;return{...o,driverId:S.user.uid,driverName:S.profile.name,status:'driver_assigned',acceptedAt:Date.now()}});toast(r.committed?'Mission acceptée':'Déjà prise');renderDriver()}
function renderDriver(){$('driverName').textContent=S.profile.name;get(ref(db,'driverStatus/'+S.user.uid)).then(s=>{$('driverOnline').checked=!!s.val()?.online;$('driverStatus').textContent=s.val()?.online?'🟢 En ligne':'⚪ Hors ligne'});const free=orderArr().filter(o=>o.status==='searching_driver'&&!o.driverId),mine=orderArr().filter(o=>o.driverId===S.user.uid),active=mine.find(o=>!['delivered','cancelled'].includes(o.status));$('driverNotifCount').textContent=free.length;$('driverMission').innerHTML=free.map(o=>`<div class="mission-card"><b>Nouvelle course</b><p>${esc(o.address?.text||'Destination')}</p><p>${o.distanceKm!=null?`${o.distanceKm.toFixed(1)} km · ~${o.etaMinutes} min à pied`:'Distance non estimée'}</p><p>Gain : ${money(o.deliveryFee)}</p><button class="btn primary" data-claim="${o.id}">Accepter</button></div>`).join('')||'<p class="muted">Aucune demande.</p>';document.querySelectorAll('[data-claim]').forEach(b=>b.onclick=()=>claim(b.dataset.claim));$('driverKpis').innerHTML=`<div class="kpi"><strong>${mine.length}</strong><span>Missions</span></div><div class="kpi"><strong>${mine.filter(x=>x.status==='delivered').length}</strong><span>Livrées</span></div><div class="kpi"><strong>${money(mine.filter(x=>x.status==='delivered').reduce((s,x)=>s+(x.deliveryFee||0),0))}</strong><span>Gains</span></div>`;$('driverDeliveries').innerHTML=mine.map(o=>`<div class="card"><b>${o.id.slice(-8)}</b> · ${label(o.status)}</div>`).join('');setTimeout(()=>{const m=leaflet('driverMap');m.invalidateSize();if(active?.address?.geo)L.marker([active.address.geo.lat,active.address.geo.lng]).addTo(m).bindPopup('Client')},80);$('driverGoogleMapsBtn').classList.toggle('hidden',!active?.address?.geo);$('driverGoogleMapsBtn').onclick=()=>navigator.geolocation?.getCurrentPosition(p=>openGoogle(active.address.geo,{lat:p.coords.latitude,lng:p.coords.longitude}),()=>openGoogle(active.address.geo))}
function ownPartner(){return Object.entries(S.partners).find(([,p])=>p.ownerId===S.user.uid)}
function partnerOrderCard(o){
  const distTxt=o.distanceKm!=null?`${o.distanceKm.toFixed(1)} km · ~${o.etaMinutes} min à pied`:'Distance non estimée';
  let actions='';
  if(o.status==='pending_restaurant'){
    actions=`<div class="mission-actions"><button class="mini-btn danger" data-refuse="${o.id}">Refuser</button><button class="mini-btn" data-accept="${o.id}">Accepter</button></div>`;
  }else if(o.status==='preparing'){
    actions=`<div class="mission-actions"><button class="mini-btn" data-ready="${o.id}">Prêt — chercher un livreur</button></div>`;
  }else if(o.status==='searching_driver'){
    actions=`<p class="muted">En attente qu'un livreur accepte la course.</p>`;
  }else if(o.status==='driver_assigned'||o.status==='on_the_way'){
    actions=`<p class="muted">${o.driverName?`Livreur : ${esc(o.driverName)} · `:''}${label(o.status)}</p>`;
  }
  return`<div class="admin-row"><div><b>${esc(o.clientName||'Client')}</b><small>${o.items.map(x=>`${x.qty}× ${esc(x.name)}`).join(', ')}</small><small>${distTxt} · ${money(o.deliveryFee)} livraison</small></div>${actions}</div>`;
}
async function setOrderStatus(id,status){await update(ref(db,'orders/'+id),{status,[status+'At']:Date.now()})}
function renderPartner(){const e=ownPartner();if(!e){$('partnerSpaceName').textContent='Compte partenaire';$('partnerStatusCard').innerHTML='<div class="card">Ton compte partenaire doit être rattaché par un administrateur à un établissement existant.</div>';$('partnerOrders').innerHTML='';$('partnerProducts').innerHTML='';$('partnerPosts').innerHTML='';return}const[id,p]=e;$('partnerSpaceName').textContent=p.name;$('partnerStatusCard').innerHTML=`<div class="card"><span class="status">${esc(p.status||'active')}</span><p>${esc(p.address||'')}</p></div>`;

  const myOrders=orderArr().filter(o=>o.partnerId===id&&!['delivered','cancelled'].includes(o.status)).sort((a,b)=>b.createdAt-a.createdAt);
  $('partnerOrders').innerHTML=myOrders.length?myOrders.map(partnerOrderCard).join(''):'<p class="muted">Aucune commande en cours.</p>';
  document.querySelectorAll('[data-accept]').forEach(b=>b.onclick=()=>setOrderStatus(b.dataset.accept,'preparing'));
  document.querySelectorAll('[data-refuse]').forEach(b=>b.onclick=()=>setOrderStatus(b.dataset.refuse,'cancelled'));
  document.querySelectorAll('[data-ready]').forEach(b=>b.onclick=()=>setOrderStatus(b.dataset.ready,'searching_driver'));

  const ps=Object.entries(S.products[id]||{});
$('partnerProducts').innerHTML=ps.length?Object.entries(groupProducts(ps)).map(([cat,items])=>`
  <div class="menu-group">
    <h4 class="menu-group-title">${esc(cat)}</h4>
    ${items.map(([k,x])=>`<div class="admin-row"><div><b>${esc(x.name)}</b>${x.tag?`<span class="dish-tag dish-tag-${x.tag}">${menuTagLabel(x.tag)}</span>`:''}<small>${money(x.price)} · ${x.available===false?'Indispo':'Disponible'}</small></div><div><button class="mini-btn" data-pe="${k}">Modifier</button><button class="mini-btn danger" data-pd="${k}">Suppr.</button></div></div>`).join('')}
  </div>`).join(''):'<p class="muted">Aucun produit. Ajoute ton premier plat !</p>';
document.querySelectorAll('[data-pe]').forEach(b=>b.onclick=()=>productModal(id,b.dataset.pe));document.querySelectorAll('[data-pd]').forEach(b=>b.onclick=()=>remove(ref(db,`products/${id}/${b.dataset.pd}`)));if($('bulkImportBtn'))$('bulkImportBtn').onclick=()=>bulkImportModal(id);const posts=Object.entries(S.posts).filter(([,x])=>x.partnerId===id);$('partnerPosts').innerHTML=posts.map(([k,x])=>`<div class="admin-row"><div><b>${esc(x.title)}</b><small>${esc(x.text||'')}</small></div><div><button class="mini-btn" data-poste="${k}">Modifier</button><button class="mini-btn danger" data-postd="${k}">Suppr.</button></div></div>`).join('')||'<p class="muted">Aucune publication.</p>';document.querySelectorAll('[data-poste]').forEach(b=>b.onclick=()=>postModal(id,b.dataset.poste));document.querySelectorAll('[data-postd]').forEach(b=>b.onclick=()=>remove(ref(db,'posts/'+b.dataset.postd)));$('addProductBtn').onclick=()=>productModal(id);$('addPostBtn').onclick=()=>postModal(id)}
function modal(title,html){$('modalTitle').textContent=title;$('modalBody').innerHTML=html;$('modal').classList.remove('hidden')}function close(){$('modal').classList.add('hidden')}$('modalClose').onclick=close;
function parseMenuText(text){
  return text.split('\n').map(line=>{
    line=line.trim();if(!line)return null;
    const m=line.match(/^(.*?)[\s.\-–—:]{1,}([\d][\d\s.,]*\d|\d)\s*(?:ar|a)?\.?$/i);
    if(!m)return null;
    const name=m[1].replace(/[-–—.\s]+$/,'').trim();
    const price=parseInt(m[2].replace(/[^\d]/g,''),10);
    if(!name||!price)return null;
    return{name,price};
  }).filter(Boolean);
}
function bulkImportModal(pid){
  modal('Importer un menu (texte)',`<div class="stack">
    <p class="muted">Colle ton menu, une ligne par plat. Ex : <code>Sambos poulet 400</code> ou <code>Margarita ... 17.000 Ar</code></p>
    <textarea id="bulkText" rows="8" placeholder="Sambos poulet 400
Sambos bœuf 400
Romazava au bœuf 4500
Jus de baobab 1000"></textarea>
    <label>Catégorie à appliquer à toutes les lignes<select id="bulkCat">${DISH_CATEGORIES.map(c=>`<option value="${c}">${c}</option>`).join('')}</select></label>
    <button id="bulkAnalyze" class="btn primary">Analyser</button>
    <div id="bulkPreviewWrap"></div>
  </div>`);
  $('bulkAnalyze').onclick=()=>{
    const rows=parseMenuText($('bulkText').value),cat=$('bulkCat').value;
    if(!rows.length){$('bulkPreviewWrap').innerHTML='<p class="muted">Aucune ligne reconnue. Vérifie le format (nom puis prix).</p>';return}
    $('bulkPreviewWrap').innerHTML=`<p class="muted">${rows.length} plat(s) détecté(s) — vérifie et corrige si besoin avant d'importer :</p>
      <div id="bulkRows" class="stack">${rows.map((r,i)=>`
        <div class="admin-row bulk-row">
          <input data-bn="${i}" value="${esc(r.name)}">
          <input data-bp="${i}" type="number" value="${r.price}">
          <button class="mini-btn danger" data-bx="${i}">✕</button>
        </div>`).join('')}</div>
      <button id="bulkConfirm" class="btn primary">Importer ${rows.length} plat(s) dans « ${cat} »</button>`;
    document.querySelectorAll('[data-bx]').forEach(b=>b.onclick=()=>{b.closest('.bulk-row').remove()});
    $('bulkConfirm').onclick=async()=>{
      const writes={};
      document.querySelectorAll('#bulkRows .bulk-row').forEach(row=>{
        const name=row.querySelector('[data-bn]').value.trim(),price=+row.querySelector('[data-bp]').value;
        if(!name||!price)return;
        const id=push(ref(db,'products/'+pid)).key;
        writes[`products/${pid}/${id}`]={name,price,category:cat,description:'',tag:'',imageUrl:'',available:true,updatedAt:Date.now()};
      });
      const n=Object.keys(writes).length;if(!n)return toast('Rien à importer');
      await update(ref(db),writes);
      close();toast(`${n} plat(s) importé(s) dans le menu`);
    };
  };
}
const DISH_CATEGORIES=['Plats','Sambos','Grillades','Sandwichs','Boissons','Desserts','Entrées','Autre'];
const DISH_TAGS={'':'Aucune','jour':'⭐ Plat du jour','chef':'👨‍🍳 Plat du chef','nouveau':'🆕 Nouveauté'};
function menuTagLabel(t){return DISH_TAGS[t||'']&&t?DISH_TAGS[t]:''}
function groupProducts(entries){const g={};entries.forEach(([k,x])=>{const c=x.category||'Autre';(g[c]=g[c]||[]).push([k,x])});return g}
function productModal(pid,k=null){
  const x=k?(S.products[pid]||{})[k]:{};
  const knownCat=DISH_CATEGORIES.includes(x.category)?x.category:'Plats';
  const customCat=DISH_CATEGORIES.includes(x.category)?'':(x.category||'');
  modal(k?'Modifier produit':'Ajouter produit',`<form id="mf" class="stack">
    <label>Nom du plat<input id="mn" value="${esc(x.name||'')}" required placeholder="Ex: Sambos poulet"></label>
    <label>Description<textarea id="md">${esc(x.description||'')}</textarea></label>
    <label>Prix (Ar)<input id="mp" type="number" value="${x.price||''}" required></label>
    <label>Catégorie du menu<select id="mc">${DISH_CATEGORIES.map(c=>`<option value="${c}" ${c===knownCat?'selected':''}>${c}</option>`).join('')}</select></label>
    <label id="mcoWrap" class="${knownCat==='Autre'?'':'hidden'}">Nom de la catégorie<input id="mco" value="${esc(customCat)}" placeholder="Ex: Boissons chaudes"></label>
    <label>Mise en avant<select id="mt">${Object.entries(DISH_TAGS).map(([v,l])=>`<option value="${v}" ${(x.tag||'')===v?'selected':''}>${l}</option>`).join('')}</select></label>
    <label>URL photo<input id="mi" value="${esc(x.imageUrl||'')}"></label>
    <label><input id="ma" type="checkbox" ${x.available===false?'':'checked'}> Disponible</label>
    <button class="btn primary">Enregistrer</button>
  </form>`);
  $('mc').onchange=()=>$('mcoWrap').classList.toggle('hidden',$('mc').value!=='Autre');
  $('mf').onsubmit=async e=>{
    e.preventDefault();
    const id=k||push(ref(db,'products/'+pid)).key;
    const cat=$('mc').value==='Autre'?($('mco').value.trim()||'Autre'):$('mc').value;
    await set(ref(db,`products/${pid}/${id}`),{name:$('mn').value,description:$('md').value,price:+$('mp').value,category:cat,tag:$('mt').value,imageUrl:$('mi').value,available:$('ma').checked,updatedAt:Date.now()});
    close()
  }
}
function postModal(pid,k=null){const x=k?S.posts[k]:{};modal(k?'Modifier publication':'Publier',`<form id="pf" class="stack"><label>Titre<input id="pt" value="${esc(x.title||'')}" required></label><label>Texte<textarea id="px">${esc(x.text||'')}</textarea></label><label>URL photo<input id="pi" value="${esc(x.imageUrl||'')}"></label><button class="btn primary">Publier</button></form>`);$('pf').onsubmit=async e=>{e.preventDefault();const id=k||push(ref(db,'posts')).key;await set(ref(db,'posts/'+id),{partnerId:pid,ownerId:S.user.uid,title:$('pt').value,text:$('px').value,imageUrl:$('pi').value,createdAt:x.createdAt||Date.now(),updatedAt:Date.now()});close()}}
document.querySelectorAll('[data-admin-tab]').forEach(b=>b.onclick=()=>{S.adminTab=b.dataset.adminTab;document.querySelectorAll('[data-admin-tab]').forEach(x=>x.classList.toggle('active',x===b));renderAdmin()});function renderAdmin(){const os=orderArr();$('adminKpis').innerHTML=`<div class="admin-kpi"><strong>${os.length}</strong><span>Commandes</span></div><div class="admin-kpi"><strong>${Object.keys(S.partners).length}</strong><span>Partenaires</span></div><div class="admin-kpi"><strong>${Object.keys(S.ads).length}</strong><span>Publicités</span></div>`;const c=$('adminTabContent');if(S.adminTab==='orders'){c.innerHTML=os.map(o=>`<div class="admin-row"><div><b>${o.id.slice(-8)}</b><small>${esc(o.clientName||'')} · ${money(o.total)}</small></div><select data-os="${o.id}"><option value="pending_restaurant">Nouvelle commande</option><option value="preparing">Préparation</option><option value="searching_driver">Recherche livreur</option><option value="driver_assigned">Livreur attribué</option><option value="on_the_way">En route</option><option value="delivered">Livrée</option><option value="cancelled">Annulée</option></select></div>`).join('');document.querySelectorAll('[data-os]').forEach(s=>{s.value=S.orders[s.dataset.os].status;s.onchange=()=>update(ref(db,'orders/'+s.dataset.os),{status:s.value})})}else if(S.adminTab==='partners')adminPartners(c);else if(S.adminTab==='products')adminProducts(c);else if(S.adminTab==='posts')adminPosts(c);else if(S.adminTab==='ads')adminAds(c);else if(S.adminTab==='places')adminPlaces(c);else adminUsers(c)}
function adminPartners(c){c.innerHTML=`<div class="section-title"><h3>Partenaires</h3><button id="apadd" class="small">+ Ajouter</button></div>`+Object.entries(S.partners).map(([k,p])=>`<div class="admin-row"><div><b>${esc(p.name)}</b><small>${esc(p.category||'')} · ${esc(p.status||'')}</small></div><div><button class="mini-btn" data-ape="${k}">Modifier</button><button class="mini-btn danger" data-apd="${k}">Suppr.</button></div></div>`).join('');$('apadd').onclick=()=>partnerModal();document.querySelectorAll('[data-ape]').forEach(b=>b.onclick=()=>partnerModal(b.dataset.ape));document.querySelectorAll('[data-apd]').forEach(b=>b.onclick=()=>remove(ref(db,'partners/'+b.dataset.apd)))}
function partnerModal(k=null){
  const p=k?S.partners[k]:{};
  modal(k?'Modifier partenaire':'Ajouter partenaire',`
    <form id="af" class="stack">
      <label>Nom<input id="an" value="${esc(p.name||'')}" required></label>
      <label>Catégorie<input id="ac" value="${esc(p.category||'Restaurant')}"></label>
      <label>Adresse<input id="aa" value="${esc(p.address||'Toliara')}"></label>
      <div class="coord-grid">
        <label>Latitude<input id="alat" type="number" step="any" value="${p.lat??p.latitude??''}" placeholder="-23.35"></label>
        <label>Longitude<input id="alng" type="number" step="any" value="${p.lng??p.longitude??''}" placeholder="43.67"></label>
      </div>
      <small class="muted">Ces coordonnées font apparaître le restaurant sur la carte client.</small>
      <label>Logo URL<input id="al" value="${esc(p.logoUrl||'')}"></label>
      <label>UID propriétaire (optionnel)<input id="ao" value="${esc(p.ownerId||'')}"></label>
      <label>Statut<select id="as"><option value="active">Actif</option><option value="pending">En attente</option><option value="suspended">Suspendu</option></select></label>
      <button class="btn primary">Enregistrer</button>
    </form>`);
  $('as').value=p.status||'active';
  $('af').onsubmit=async e=>{
    e.preventDefault();
    const id=k||push(ref(db,'partners')).key;
    const lat=parseFloat($('alat').value),lng=parseFloat($('alng').value);
    await set(ref(db,'partners/'+id),{
      name:$('an').value,category:$('ac').value,address:$('aa').value,
      lat:Number.isFinite(lat)?lat:null,lng:Number.isFinite(lng)?lng:null,
      logoUrl:$('al').value,ownerId:$('ao').value,status:$('as').value,updatedAt:Date.now()
    });
    close();
  }
}
function adminProducts(c){let rows='';for(const[pid,prods]of Object.entries(S.products))for(const[k,x]of Object.entries(prods||{}))rows+=`<div class="admin-row"><div><b>${esc(x.name)}</b><small>${esc(S.partners[pid]?.name||pid)} · ${money(x.price)}</small></div><div><button class="mini-btn" data-aeditp="${pid}|${k}">Modifier</button><button class="mini-btn danger" data-adelp="${pid}|${k}">Suppr.</button></div></div>`;c.innerHTML=`<div class="section-title"><h3>Menus</h3><div><button id="adminProdAdd" class="small">+ Produit</button> <button id="adminBulkAdd" class="small">📋 Importer texte</button></div></div>`+rows;$('adminProdAdd').onclick=()=>adminProductPicker();$('adminBulkAdd').onclick=()=>{const opts=Object.entries(S.partners).map(([k,p])=>`<option value="${k}">${esc(p.name)}</option>`).join('');modal('Importer un menu — choisir le partenaire',`<div class="stack"><label>Partenaire<select id="pickPartnerBulk">${opts}</select></label><button id="pickBulkContinue" class="btn primary">Continuer</button></div>`);$('pickBulkContinue').onclick=()=>bulkImportModal($('pickPartnerBulk').value)};document.querySelectorAll('[data-aeditp]').forEach(b=>b.onclick=()=>{const[a,k]=b.dataset.aeditp.split('|');productModal(a,k)});document.querySelectorAll('[data-adelp]').forEach(b=>b.onclick=()=>{const[a,k]=b.dataset.adelp.split('|');remove(ref(db,`products/${a}/${k}`))})}function adminProductPicker(){const opts=Object.entries(S.partners).map(([k,p])=>`<option value="${k}">${esc(p.name)}</option>`).join('');modal('Ajouter un produit',`<div class="stack"><label>Partenaire<select id="pickPartner">${opts}</select></label><button id="pickContinue" class="btn primary">Continuer</button></div>`);$('pickContinue').onclick=()=>productModal($('pickPartner').value)}
function adminPosts(c){c.innerHTML=`<div class="section-title"><h3>Publications</h3><button id="adminPostAdd" class="small">+ Publier</button></div>`+Object.entries(S.posts).map(([k,p])=>`<div class="admin-row"><div><b>${esc(p.title)}</b><small>${esc(S.partners[p.partnerId]?.name||'Admin')}</small></div><div><button class="mini-btn danger" data-adpost="${k}">Suppr.</button></div></div>`).join('');$('adminPostAdd').onclick=()=>{const opts=Object.entries(S.partners).map(([k,p])=>`<option value="${k}">${esc(p.name)}</option>`).join('');modal('Publier pour un partenaire',`<div class="stack"><label>Partenaire<select id="postPartner">${opts}</select></label><button id="postCont" class="btn primary">Continuer</button></div>`);$('postCont').onclick=()=>postModal($('postPartner').value)};document.querySelectorAll('[data-adpost]').forEach(b=>b.onclick=()=>remove(ref(db,'posts/'+b.dataset.adpost)))}
function adminAds(c){c.innerHTML=`<div class="section-title"><h3>Publicités</h3><button id="adAdd" class="small">+ Pub</button></div>`+Object.entries(S.ads).map(([k,a])=>`<div class="admin-row"><div><b>${esc(a.title)}</b><small>${a.active===false?'Inactive':'Active'}</small></div><div><button class="mini-btn" data-ae="${k}">Modifier</button><button class="mini-btn danger" data-ad="${k}">Suppr.</button></div></div>`).join('');$('adAdd').onclick=()=>adModal();document.querySelectorAll('[data-ae]').forEach(b=>b.onclick=()=>adModal(b.dataset.ae));document.querySelectorAll('[data-ad]').forEach(b=>b.onclick=()=>remove(ref(db,'ads/'+b.dataset.ad)))}function adModal(k=null){const a=k?S.ads[k]:{};modal(k?'Modifier pub':'Nouvelle pub',`<form id="adf" class="stack"><label>Titre<input id="adt" value="${esc(a.title||'')}" required></label><label>Texte<textarea id="adx">${esc(a.text||'')}</textarea></label><label>URL image<input id="adi" value="${esc(a.imageUrl||'')}"></label><label><input id="ada" type="checkbox" ${a.active===false?'':'checked'}> Active</label><button class="btn primary">Enregistrer</button></form>`);$('adf').onsubmit=async e=>{e.preventDefault();const id=k||push(ref(db,'ads')).key;await set(ref(db,'ads/'+id),{title:$('adt').value,text:$('adx').value,imageUrl:$('adi').value,active:$('ada').checked,updatedAt:Date.now()});close()}}
function adminPlaces(c){c.innerHTML=`<div class="section-title"><h3>Lieux</h3><button id="plAdd" class="small">+ Lieu</button></div>`+Object.entries(S.places).map(([k,p])=>`<div class="admin-row"><div><b>${esc(p.name)}</b><small>${esc(p.address||'')}</small></div><button class="mini-btn danger" data-pld="${k}">Suppr.</button></div>`).join('');$('plAdd').onclick=()=>{modal('Ajouter lieu',`<form id="plf" class="stack"><label>Nom<input id="pln" required></label><label>Adresse<input id="pla"></label><label>Latitude<input id="pll" type="number" step="any"></label><label>Longitude<input id="plg" type="number" step="any"></label><button class="btn primary">Ajouter</button></form>`);$('plf').onsubmit=async e=>{e.preventDefault();const k=push(ref(db,'places')).key;await set(ref(db,'places/'+k),{name:$('pln').value,address:$('pla').value,lat:+$('pll').value,lng:+$('plg').value,active:true});close()}};document.querySelectorAll('[data-pld]').forEach(b=>b.onclick=()=>remove(ref(db,'places/'+b.dataset.pld)))}
function adminUsers(c){get(ref(db,'users')).then(s=>{const u=s.val()||{};c.innerHTML=Object.entries(u).map(([k,x])=>`<div class="admin-row"><div><b>${esc(x.name||x.email)}</b><small>${esc(x.email||'')}</small></div><select data-ur="${k}"><option value="client">Client</option><option value="driver">Livreur</option><option value="partner">Partenaire</option><option value="admin">Admin</option></select></div>`).join('');document.querySelectorAll('[data-ur]').forEach(sel=>{sel.value=u[sel.dataset.ur].role;sel.onchange=()=>update(ref(db,'users/'+sel.dataset.ur),{role:sel.value})})})}
