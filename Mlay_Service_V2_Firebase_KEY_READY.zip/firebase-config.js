import { initializeApp } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, setPersistence, browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-database.js";

export const firebaseConfig = {
  apiKey: "AIzaSyBClpV55vzmYjFxqdU9Y3VkmfU2",
  authDomain: "mlay-17f69.firebaseapp.com",
  databaseURL: "https://mlay-17f69-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "mlay-17f69",
  storageBucket: "mlay-17f69.firebasestorage.app",
  messagingSenderId: "434554342526",
  appId: "1:434554342526:web:0b98cc8252f5e7ee69dc2f"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
export const googleProvider = new GoogleAuthProvider();

setPersistence(auth, browserLocalPersistence).catch(console.error);