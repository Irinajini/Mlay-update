// M'lay Service — configuration optionnelle.
// Le site fonctionne immédiatement en mode local (localStorage).
// Pour passer plus tard à Firebase, place ici ta configuration Firebase
// puis remplace le service local par les appels Auth/Firestore.
window.MLAY_CONFIG = {
  appName: "M'lay Service",
  city: "Toliara",
  currency: "Ar",
  firebase: null
};
