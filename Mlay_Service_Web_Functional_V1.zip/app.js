(() => {
  const KEY = 'mlay_service_v1';
  const STATUS = ['Commande reçue','En préparation','Livreur en route','Livrée'];
  const categories = ['Tous','Restaurants','Boutiques','Pharmacies','Courses','Colis'];
  const partners = [
    {id:'habibs',name:"Habib'S Fast Food",category:'Restaurants',icon:'🍔',rating:4.8,distance:'1,2 km',time:'20–30 min',products:[
      {id:'hb1',name:"Cheeseburger M'lay",price:15000,icon:'🍔'}, {id:'hb2',name:'Sandwich Bleu',price:12000,icon:'🥪'}, {id:'hb3',name:'Frites',price:6000,icon:'🍟'}, {id:'hb4',name:'Boisson fraîche',price:3500,icon:'🥤'}]},
    {id:'zanteny',name:'Food Zanteny Bleu',category:'Restaurants',icon:'🍗',rating:4.6,distance:'2,0 km',time:'25–35 min',products:[
      {id:'za1',name:'Poulet grillé',price:18000,icon:'🍗'}, {id:'za2',name:'Riz composé',price:10000,icon:'🍛'}, {id:'za3',name:'Jus naturel',price:5000,icon:'🧃'}]},
    {id:'shop',name:"Boutique M'lay",category:'Boutiques',icon:'🛍️',rating:4.7,distance:'1,6 km',time:'20–30 min',products:[
      {id:'sh1',name:'Pack eau',price:9000,icon:'💧'}, {id:'sh2',name:'Biscuits',price:4500,icon:'🍪'}, {id:'sh3',name:'Produits du quotidien',price:7500,icon:'🧺'}]},
    {id:'pharma',name:'Pharmacie du Sud',category:'Pharmacies',icon:'💊',rating:4.9,distance:'0,8 km',time:'15–20 min',products:[
      {id:'ph1',name:'Parapharmacie',price:5000,icon:'🧴'}, {id:'ph2',name:'Hygiène',price:7000,icon:'🧼'}]},
    {id:'courses',name:'M’lay Courses',category:'Courses',icon:'🧺',rating:4.8,distance:'Variable',time:'Selon liste',products:[
      {id:'co1',name:'Service de courses',price:5000,icon:'🧺'}]},
    {id:'parcel',name:'M’lay Colis',category:'Colis',icon:'📦',rating:4.8,distance:'Toliara',time:'Selon trajet',products:[
      {id:'pa1',name:'Petit colis',price:5000,icon:'📦'}, {id:'pa2',name:'Colis moyen',price:8000,icon:'📦'}]}
  ];
  const demoUsers = [
    {id:'u-client',name:'Client M’lay',email:'client@mlay.mg',phone:'+261 34 00 000 01',password:'mlay123',role:'client'},
    {id:'u-driver',name:'Tojo R.',email:'livreur@mlay.mg',phone:'+261 34 00 000 02',password:'mlay123',role:'driver'},
    {id:'u-admin',name:'Administrateur M’lay',email:'admin@mlay.mg',phone:'+261 34 00 000 03',password:'mlayadmin',role:'admin'}
  ];
  const defaultState = {users:demoUsers,session:null,cart:[],orders:[],address:null,activeMerchant:'habibs',activeOrder:null,category:'Tous'};
  let state = load();

  function load(){ try { return {...defaultState,...JSON.parse(localStorage.getItem(KEY)||'{}')}; } catch { return structuredClone(defaultState); } }
  function save(){ localStorage.setItem(KEY, JSON.stringify(state)); }
  function money(n){ return new Intl.NumberFormat('fr-FR').format(n)+' Ar'; }
  function toast(msg){ const el=document.getElementById('toast'); el.textContent=msg; el.classList.add('show'); setTimeout(()=>el.classList.remove('show'),2200); }
  function currentUser(){ return state.users.find(u=>u.id===state.session) || null; }
  function initials(name='M'){ return name.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase(); }
  function go(name){
    if(['home','orders','cart','profile','driver','admin'].includes(name) && !currentUser()) name='auth';
    document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active',s.dataset.screen===name));
    const active=document.querySelector(`.screen[data-screen="${name}"]`); if(active) active.scrollTop=0;
    if(name==='home') renderHome(); if(name==='merchant') renderMerchant(); if(name==='cart') renderCart(); if(name==='orders') renderOrders(); if(name==='profile') renderProfile(); if(name==='tracking') renderTracking(); if(name==='checkout') renderCheckout(); if(name==='driver') renderDriver(); if(name==='admin') renderAdmin();
  }
  document.addEventListener('click',e=>{ const goEl=e.target.closest('[data-go]'); if(goEl){ e.preventDefault(); go(goEl.dataset.go); } });

  document.querySelector('[data-action="start"]').addEventListener('click',()=>go(currentUser()?'home':'auth'));
  setTimeout(()=>{ if(document.querySelector('[data-screen="splash"]').classList.contains('active')) go(currentUser()?'home':'auth'); },1600);

  document.querySelectorAll('[data-auth-tab]').forEach(b=>b.addEventListener('click',()=>{
    const login=b.dataset.authTab==='login'; document.querySelectorAll('[data-auth-tab]').forEach(x=>x.classList.toggle('active',x===b));
    document.getElementById('loginForm').classList.toggle('hidden',!login); document.getElementById('registerForm').classList.toggle('hidden',login);
  }));
  document.getElementById('loginForm').addEventListener('submit',e=>{
    e.preventDefault(); const id=document.getElementById('loginId').value.trim().toLowerCase(); const pwd=document.getElementById('loginPassword').value;
    const u=state.users.find(x=>(x.email.toLowerCase()===id||x.phone.replace(/\s/g,'')===id.replace(/\s/g,''))&&x.password===pwd);
    if(!u) return toast('Identifiants incorrects'); state.session=u.id; save(); toast(`Bienvenue ${u.name}`); go(u.role==='admin'?'admin':u.role==='driver'?'driver':'home');
  });
  document.getElementById('registerForm').addEventListener('submit',e=>{
    e.preventDefault(); const email=document.getElementById('regEmail').value.trim().toLowerCase(); if(state.users.some(u=>u.email.toLowerCase()===email)) return toast('Cet email existe déjà');
    const u={id:'u-'+Date.now(),name:document.getElementById('regName').value.trim(),email,phone:document.getElementById('regPhone').value.trim(),password:document.getElementById('regPassword').value,role:'client'};
    state.users.push(u); state.session=u.id; save(); toast('Compte créé'); go('home');
  });
  document.querySelectorAll('[data-demo]').forEach(btn=>btn.addEventListener('click',()=>{
    const role=btn.dataset.demo; const u=state.users.find(x=>x.role===role); state.session=u.id; save(); go(role==='admin'?'admin':role==='driver'?'driver':'home');
  }));

  function renderHome(){
    const u=currentUser(); document.getElementById('homeAvatar').textContent=initials(u?.name);
    const cat=document.getElementById('categoryRow'); cat.innerHTML=categories.map(c=>`<button class="${state.category===c?'active':''}" data-cat="${c}">${c}</button>`).join('');
    cat.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{state.category=b.dataset.cat;save();renderHome();});
    const q=(document.getElementById('searchInput').value||'').toLowerCase();
    const filtered=partners.filter(p => (state.category==='Tous' || p.category===state.category) && (!q || `${p.name} ${p.category} ${p.products.map(x=>x.name).join(' ')}`.toLowerCase().includes(q)));
    document.getElementById('partnerCount').textContent=`${filtered.length} partenaire${filtered.length>1?'s':''}`;
    document.getElementById('partnerList').innerHTML=filtered.length?filtered.map(p=>`<button class="partner-card" data-partner="${p.id}"><span class="partner-icon">${p.icon}</span><div><h4>${p.name}</h4><p>★ ${p.rating} · ${p.distance} · ${p.time}</p><p>${p.category}</p></div><span class="arrow">›</span></button>`).join(''):'<div class="empty">Aucun partenaire trouvé.</div>';
    document.querySelectorAll('[data-partner]').forEach(b=>b.onclick=()=>{state.activeMerchant=b.dataset.partner;save();go('merchant');}); updateBadges();
  }
  document.getElementById('searchInput').addEventListener('input',renderHome);

  function merchant(){ return partners.find(p=>p.id===state.activeMerchant)||partners[0]; }
  function renderMerchant(){
    const p=merchant(); document.getElementById('merchantName').textContent=p.name; document.getElementById('merchantHeroName').textContent=p.name; document.getElementById('merchantCategory').textContent=p.category; document.getElementById('merchantMeta').textContent=`★ ${p.rating} · ${p.distance} · ${p.time}`;
    document.getElementById('productList').innerHTML=p.products.map(x=>`<div class="product-card"><span class="product-icon">${x.icon}</span><div><h4>${x.name}</h4><p>${money(x.price)}</p></div><button class="add-btn" data-add="${x.id}">Ajouter</button></div>`).join('');
    document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>addToCart(p.id,b.dataset.add)); updateBadges();
  }
  function addToCart(partnerId,productId){ const p=partners.find(x=>x.id===partnerId), prod=p.products.find(x=>x.id===productId); const row=state.cart.find(x=>x.productId===productId); if(row) row.qty++; else state.cart.push({partnerId,productId,name:prod.name,price:prod.price,icon:prod.icon,qty:1}); save(); toast(`${prod.name} ajouté`); updateBadges(); }
  function updateBadges(){ const n=state.cart.reduce((s,x)=>s+x.qty,0); const badge=document.getElementById('navCartBadge'); if(badge){badge.textContent=n;badge.classList.toggle('hidden',!n);} const f=document.getElementById('floatingCartText');if(f)f.textContent=`${n} article${n>1?'s':''}`; }
  function totals(){ const subtotal=state.cart.reduce((s,x)=>s+x.price*x.qty,0); const delivery=subtotal?3500:0; return {subtotal,delivery,total:subtotal+delivery}; }
  function renderSummary(id){ const t=totals(); document.getElementById(id).innerHTML=`<div class="summary-line"><span>Sous-total</span><span>${money(t.subtotal)}</span></div><div class="summary-line"><span>Frais de livraison</span><span>${money(t.delivery)}</span></div><div class="summary-line total"><span>Total</span><span>${money(t.total)}</span></div>`; }
  function renderCart(){
    const el=document.getElementById('cartContent'); if(!state.cart.length){ el.innerHTML='<div class="empty">🛒<h3>Ton panier est vide</h3><p>Ajoute des produits depuis les partenaires.</p></div>'; document.getElementById('cartSummary').innerHTML=''; document.getElementById('checkoutBtn').disabled=true;return; }
    document.getElementById('checkoutBtn').disabled=false; el.innerHTML=state.cart.map(x=>`<div class="cart-row"><div><h4>${x.icon} ${x.name}</h4><p>${money(x.price)} × ${x.qty}</p></div><div class="qty"><button data-minus="${x.productId}">−</button><b>${x.qty}</b><button data-plus="${x.productId}">+</button></div></div>`).join('');
    el.querySelectorAll('[data-minus]').forEach(b=>b.onclick=()=>changeQty(b.dataset.minus,-1)); el.querySelectorAll('[data-plus]').forEach(b=>b.onclick=()=>changeQty(b.dataset.plus,1)); renderSummary('cartSummary'); updateBadges();
  }
  function changeQty(id,d){ const x=state.cart.find(r=>r.productId===id); if(!x)return;x.qty+=d;if(x.qty<=0)state.cart=state.cart.filter(r=>r.productId!==id);save();renderCart(); }
  document.getElementById('checkoutBtn').onclick=()=>{if(!state.cart.length)return toast('Panier vide');go('address');};

  document.getElementById('addressForm').addEventListener('submit',e=>{e.preventDefault();state.address={label:addressLabel.value.trim(),text:addressText.value.trim(),note:addressNote.value.trim(),geo:state.address?.geo||null};save();go('checkout');});
  document.getElementById('geoBtn').onclick=()=>{ if(!navigator.geolocation)return toast('Géolocalisation indisponible'); navigator.geolocation.getCurrentPosition(pos=>{state.address={...(state.address||{}),geo:{lat:pos.coords.latitude,lng:pos.coords.longitude}};save();toast('Position enregistrée');},()=>toast('Impossible d’obtenir la position')); };
  function renderCheckout(){ renderSummary('checkoutRecap'); }
  document.getElementById('placeOrderBtn').onclick=()=>{
    if(!state.cart.length)return toast('Panier vide'); const t=totals(); const order={id:'MLY-'+String(Date.now()).slice(-7),userId:state.session,items:structuredClone(state.cart),address:state.address,total:t.total,statusIndex:0,createdAt:new Date().toISOString(),driver:null,payment:'cash'}; state.orders.unshift(order);state.activeOrder=order.id;state.cart=[];save();updateBadges();toast('Commande créée');go('tracking');
  };

  function userOrders(){return state.orders.filter(o=>o.userId===state.session);}
  function renderOrders(){ const orders=userOrders(); document.getElementById('ordersList').innerHTML=orders.length?orders.map(o=>`<button class="order-card" data-order="${o.id}"><div class="order-head"><h4>${o.id}</h4><span class="status-pill">${STATUS[o.statusIndex]}</span></div><p>${new Date(o.createdAt).toLocaleString('fr-FR')}</p><p>${o.items.length} produit(s) · <b>${money(o.total)}</b></p></button>`).join(''):'<div class="empty">Aucune commande pour le moment.</div>'; document.querySelectorAll('[data-order]').forEach(b=>b.onclick=()=>{state.activeOrder=b.dataset.order;save();go('tracking');}); }
  function activeOrder(){return state.orders.find(o=>o.id===state.activeOrder)||userOrders()[0]||state.orders[0];}
  function renderTracking(){ const o=activeOrder(); if(!o){document.getElementById('trackingInfo').innerHTML='<div class="empty">Aucune commande à suivre.</div>';document.getElementById('timeline').innerHTML='';return;} document.getElementById('trackingInfo').innerHTML=`<div class="summary-card"><b>${o.id}</b><div class="summary-line"><span>Destination</span><span>${o.address?.text||'Adresse'}</span></div><div class="summary-line"><span>Total</span><span>${money(o.total)}</span></div><div class="summary-line"><span>Paiement</span><span>À la livraison</span></div></div>`; document.getElementById('timeline').innerHTML=STATUS.map((s,i)=>`<div class="timeline-step ${i<=o.statusIndex?'done':''}"><i></i><span>${s}</span></div>`).join(''); }
  document.getElementById('advanceDemoBtn').onclick=()=>{const o=activeOrder();if(!o)return;if(o.statusIndex<STATUS.length-1)o.statusIndex++;save();renderTracking();renderAdmin();toast(STATUS[o.statusIndex]);};

  function renderProfile(){ const u=currentUser();if(!u)return;profileAvatar.textContent=initials(u.name);profileName.textContent=u.name;profileContact.textContent=`${u.email} · ${u.phone}`;const b=document.getElementById('profileRoleButton');b.classList.toggle('hidden',u.role==='client');b.onclick=()=>go(u.role==='admin'?'admin':'driver'); }
  document.getElementById('logoutBtn').onclick=()=>{state.session=null;save();toast('Déconnecté');go('auth');};

  function renderDriver(){ const u=currentUser(); if(!u||u.role!=='driver')return go('profile'); driverName.textContent=u.name; const available=state.orders.find(o=>o.statusIndex<3&&!o.driver); driverMission.innerHTML=available?`<div class="mission-card"><div class="order-head"><b>Nouvelle mission</b><span class="mission-price">+ 4 500 Ar</span></div><h4>${available.id}</h4><p>${available.address?.text||'Adresse client'}</p><div class="mission-actions"><button class="btn btn-outline" id="declineMission">Refuser</button><button class="btn btn-primary" id="acceptMission">Accepter</button></div></div>`:'<div class="empty">Aucune mission disponible actuellement.</div>'; if(available){document.getElementById('acceptMission').onclick=()=>{available.driver=u.id;available.statusIndex=Math.max(available.statusIndex,2);save();toast('Mission acceptée');renderDriver();};document.getElementById('declineMission').onclick=()=>toast('Mission ignorée');} const delivered=state.orders.filter(o=>o.driver===u.id&&o.statusIndex===3); driverKpis.innerHTML=`<div class="kpi"><strong>${delivered.length}</strong><span>Livraisons</span></div><div class="kpi"><strong>${money(delivered.length*4500)}</strong><span>Revenus</span></div><div class="kpi"><strong>4,9</strong><span>Note</span></div>`; }
  document.getElementById('driverOnline').onchange=e=>{driverStatus.textContent=e.target.checked?'🟢 En ligne':'⚪ Hors ligne';};

  function renderAdmin(){ const u=currentUser();if(!u||u.role!=='admin')return; const delivered=state.orders.filter(o=>o.statusIndex===3); const revenue=delivered.reduce((s,o)=>s+o.total,0); const clients=state.users.filter(x=>x.role==='client').length; const drivers=state.users.filter(x=>x.role==='driver').length; adminKpis.innerHTML=`<div class="admin-kpi"><strong>${state.orders.length}</strong><span>Commandes</span></div><div class="admin-kpi"><strong>${money(revenue)}</strong><span>CA livré</span></div><div class="admin-kpi"><strong>${clients}</strong><span>Clients</span></div><div class="admin-kpi"><strong>${drivers}</strong><span>Livreurs</span></div>`; adminOrders.innerHTML=state.orders.length?state.orders.slice(0,8).map(o=>`<div class="admin-table-row"><div><b>${o.id}</b><br><small>${STATUS[o.statusIndex]}</small></div><b>${money(o.total)}</b></div>`).join(''):'<p class="muted">Aucune commande.</p>'; adminPartners.innerHTML=partners.map(p=>`<div class="admin-table-row"><div><b>${p.name}</b><br><small>${p.category}</small></div><span>★ ${p.rating}</span></div>`).join(''); }

  save(); updateBadges();
})();
