# M'lay Service — Web fonctionnel V1

Version web responsive basée sur la maquette M'lay Service.

## Fonctionne immédiatement sans serveur
- inscription / connexion locale ;
- comptes démo client, livreur et admin ;
- recherche et catégories ;
- partenaires et produits ;
- panier avec quantités et calcul du total ;
- adresse et géolocalisation navigateur ;
- commande avec **paiement à la livraison uniquement** ;
- suivi de commande simulé ;
- historique client ;
- espace livreur ;
- tableau de bord administrateur ;
- sauvegarde dans `localStorage`.

## Comptes démo
- Client : `client@mlay.mg` / `mlay123`
- Livreur : `livreur@mlay.mg` / `mlay123`
- Admin : `admin@mlay.mg` / `mlayadmin`

## Important pour une vraie mise en production
Cette V1 est réellement interactive mais les données sont stockées dans le navigateur de chaque appareil. Pour un vrai service multi-utilisateur partagé entre clients, livreurs et admin, connecter ensuite Firebase Authentication + Firestore/Realtime Database. `config.js` est prévu pour cette évolution.

Les paiements en ligne ne sont volontairement pas activés. La commande utilise le paiement à la livraison.

## Déploiement GitHub Pages
Déposer le contenu du dossier à la racine du dépôt, puis GitHub > Settings > Pages > Deploy from branch > `main` / `(root)`.
