# M'LAY Service V4

Version pilote Web de M'LAY Service.

## Expérience client
Le client arrive directement sur les services :
- M'LAY Food
- M'LAY Drive
- M'LAY Colis
- M'LAY Courses

La consultation est publique. L'identification Firebase n'est demandée qu'au moment où le client veut confirmer une commande.

Voir `README_V4.md` pour le détail, les règles Firebase à déployer et les limites connues.
