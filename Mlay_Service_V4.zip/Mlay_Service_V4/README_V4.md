# M'LAY Service V4 — Service-first + identification au moment de commander

## Principe UX V4
Le client arrive d'abord sur les services M'LAY : Food, Drive, Colis et Courses. Il peut consulter les restaurants, menus, remplir son panier et obtenir des estimations sans créer de compte.

L'identification est demandée uniquement lorsqu'une action engage réellement une commande :
- Food : au clic sur Continuer depuis le panier
- Drive : au clic sur Commander ce trajet
- Colis : au clic sur Commander cette livraison
- Courses : au clic sur Commander mes courses

## Nouveautés principales
- Accueil service-first simplifié
- Navigation invitée sans authentification
- M'LAY Food conservé et accessible publiquement
- M'LAY Drive avec carte, départ, destination, véhicule et estimation
- M'LAY Colis avec taille, destinataire, carte et estimation
- M'LAY Courses avec liste d'achats, budget et livraison
- Nouvelle branche Firebase `serviceRequests`
- Nouvelle branche Firebase `pricing`
- Espace livreur capable de prendre les missions Food + Drive/Colis/Courses
- Historique client unifié
- Administration des demandes de services et tarifs
- Règles Firebase V4 renforcées, notamment contre l'auto-promotion d'un client en admin

## Important avant mise en production
1. Déployer `database.rules.json` dans Firebase Realtime Database.
2. Vérifier les domaines autorisés dans Firebase Authentication.
3. Tester les 4 rôles : client, driver, partner, admin.
4. La recherche Nominatim existante reste adaptée à un pilote, pas à une forte charge commerciale.
5. Les notifications push et le GPS livreur en arrière-plan ne sont pas encore inclus dans cette V4 Web. Ils demandent une étape mobile/FCM dédiée.

## Tarifs par défaut V4
Ils sont utilisés uniquement si `/pricing` n'est pas encore configuré dans Firebase.
- Drive moto : minimum 3 000 Ar + 800 Ar/km
- Drive voiture : minimum 5 000 Ar + 1 200 Ar/km
- Colis : minimum 4 000 Ar + 900 Ar/km
- Courses : minimum 4 000 Ar + 700 Ar/km

L'admin peut ensuite modifier ces valeurs depuis l'onglet Tarifs.
