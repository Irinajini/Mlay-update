# M'lay Service — V3.7 (Relation resto ↔ client, tarif à la distance)

## Nouveautés

### 1. Le restaurant est maintenant dans la boucle
- Nouveau statut de commande **`pending_restaurant`** : dès qu'un client commande, la commande arrive d'abord chez le restaurant, pas directement en recherche de livreur.
- Espace partenaire → nouvelle section **"Commandes"** : chaque commande en cours s'affiche avec les articles, la distance, et des boutons d'action :
  - **Nouvelle commande** → `Refuser` (annule) ou `Accepter` (passe en préparation).
  - **En préparation** → `Prêt — chercher un livreur` (déclenche la recherche, visible aux livreurs seulement à partir de ce moment).
  - **Recherche livreur / Livreur en route** → affichage lecture seule (le restaurant voit où en est la commande, sans rien à faire).
- Le client voit cette même progression sur son écran de suivi (nouvelle timeline : Nouvelle commande → Préparation → Recherche livreur → Livreur en route → Livrée).

### 2. Frais de livraison calculés à la distance
- Nouvelle fonction `estimateDelivery()` : calcule la distance à vol d'oiseau (formule de Haversine) entre le restaurant et l'adresse du client.
- Tarif entre **2 500 Ar** (livraison très proche) et **5 000 Ar** (livraison la plus éloignée dans Toliara), qui augmente progressivement avec la distance.
- **+25% le soir** (à partir de 18h, dans la fourchette 20-30% demandée) — réglable via la constante `EVENING_SURCHARGE` en haut de `app.js`.
- Estimation du temps de trajet basée sur une vitesse de marche moyenne (4,5 km/h, car la livraison se fait à pied), affichée au client, au restaurant et au livreur : *"1.8 km · ~24 min à pied"*.
- Si l'adresse du client ou la position du restaurant n'est pas encore connue (pas de GPS enregistré), un tarif moyen par défaut (3 500 Ar) est utilisé en attendant, clairement indiqué comme estimation.

## Réglages rapides (dans `app.js`, tout en haut)
```js
const WALK_SPEED_KMH = 4.5;
const DELIVERY_FEE_MIN = 2500;
const DELIVERY_FEE_MAX = 5000;
const DELIVERY_FEE_MAX_DISTANCE_KM = 3.5; // distance à partir de laquelle le tarif plafonne à 5000 Ar
const EVENING_START_HOUR = 18;
const EVENING_SURCHARGE = 0.25; // 25% — modifiable entre 0.20 et 0.30
```

## Fichiers modifiés
- `app.js` — calcul distance/prix/ETA, nouveau flux de statuts, gestion des commandes côté partenaire.
- `index.html` — nouvelle section "Commandes" dans l'écran partenaire.
- `style.css` — style du groupe de boutons d'action (`.mission-actions`).

## Point de vigilance pour plus tard
Les règles Firebase (`database.rules.json`) autorisent actuellement **tout utilisateur connecté** à modifier n'importe quelle commande (`orders/$orderId : auth != null`). Ça fonctionne, mais ce n'est pas strict : un client pourrait techniquement modifier le statut d'une commande d'un autre restaurant. À resserrer plus tard (limiter l'écriture au partenaire propriétaire, au livreur assigné, ou à l'admin) une fois que le flux global sera stabilisé — je peux le faire dès que tu veux.
