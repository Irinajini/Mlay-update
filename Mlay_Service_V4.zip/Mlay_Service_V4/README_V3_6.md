# M'lay Service — V3.6 (Menus & Paniers multi-restaurants)

## Nouveautés

### 1. Import de menu en texte (partenaire + admin)
- Bouton "📋 Importer texte" dans l'espace partenaire et dans l'onglet Admin → Menus.
- Colle un menu ligne par ligne (`Nom Prix`, formats libres type ardoise : `Margarita ---17.000A`).
- Détection automatique nom + prix, aperçu éditable avant import, catégorie appliquée à toutes les lignes.
- Le formulaire d'ajout/modification à l'unité reste disponible (catégorie + badge "Plat du jour / Plat du chef / Nouveauté").

### 2. Catégories & mise en avant des plats
- Champ `category` (Plats, Sambos, Grillades, Sandwichs, Boissons, Desserts, Entrées, Autre) éditable.
- Champ `tag` : `jour` (⭐ Plat du jour), `chef` (👨‍🍳 Plat du chef), `nouveau` (🆕 Nouveauté).
- Menu affiché groupé par catégorie côté partenaire ET côté client.

### 3. Quantité inline sur chaque plat
- Sélecteur −/+ directement sur la fiche produit (accueil "Découvrir" et page restaurant).
- Le client choisit la quantité avant de cliquer "Ajouter".

### 4. Paniers séparés par restaurant
- Le panier est désormais groupé par restaurant : un "panier" = un restaurant.
- Chaque panier a ses propres frais de livraison (`DELIVERY_FEE_PER_BASKET`, 3 500 Ar par défaut, modifiable dans `app.js`).
- À la validation, **une commande Firebase distincte est créée par restaurant** (`orders/{id}` avec `partnerId`, `restaurantName`, `items`, `subtotal`, `deliveryFee`, `total`), chacune avec son propre statut/suivi/livreur.
- Si plusieurs commandes sont créées en une fois, le client est redirigé vers la liste "Mes commandes" plutôt que vers un suivi unique.

### 5. Correctif
- `renderSummary` n'était pas défini (bug V3.5) → l'écran panier plantait silencieusement. Corrigé (`summary()`).

## Fichiers modifiés
- `app.js`
- `style.css`
- `index.html` (bouton "📋 Importer texte" dans l'espace partenaire)

## Aucune modification nécessaire
- `database.rules.json` : les règles existantes (`ownerId === auth.uid` ou `role === 'admin'`) couvrent déjà l'écriture des menus par partenaire ET par admin.
- `firebase-config.js` : inchangé.
