# M'lay Service V3.3 — Google + Firebase Search

## Architecture hybride

### Google Places / Maps
La recherche peut trouver :
- restaurants ;
- commerces ;
- lieux ;
- catégories ;
- établissements autour de Toliara.

Les résultats Google apparaissent dans les suggestions et sur la carte.

### Firebase M'lay
Firebase reste la source pour :
- menus ;
- plats ;
- prix ;
- descriptions ;
- photos publiées par les partenaires/admin ;
- promotions ;
- commandes ;
- partenaires ;
- publicités et publications.

## Recherche
Quand le client tape "pizza", M'lay affiche :
1. les plats M'lay correspondant à "pizza" ;
2. les partenaires M'lay correspondants ;
3. les résultats Google Places à Toliara.

La carte se met à jour avec les résultats.

## Google Maps requis
Pour activer Google Places :
1. Google Cloud Console ;
2. activer Maps JavaScript API ;
3. activer Places API (New) ;
4. créer une clé API Google Maps Platform ;
5. GitHub → Settings → Secrets and variables → Actions ;
6. créer `GOOGLE_MAPS_API_KEY` avec la clé complète.

Le workflow V3.3 injecte automatiquement cette clé dans `google-config.js`.

Si `GOOGLE_MAPS_API_KEY` n'existe pas, le site reste fonctionnel avec Firebase + OpenStreetMap, mais sans résultats Google Places.

## Correspondance Google ↔ M'lay
L'admin peut enregistrer un `googlePlaceId` sur chaque partenaire M'lay.
Cela permettra d'identifier précisément qu'un restaurant Google est aussi un partenaire M'lay.