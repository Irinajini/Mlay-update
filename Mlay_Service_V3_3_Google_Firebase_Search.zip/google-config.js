export const GOOGLE_MAPS_API_KEY = "__GOOGLE_MAPS_API_KEY__";

export function googleMapsConfigured(){
  return Boolean(
    GOOGLE_MAPS_API_KEY &&
    !GOOGLE_MAPS_API_KEY.includes("__GOOGLE_MAPS_API_KEY__") &&
    GOOGLE_MAPS_API_KEY.length > 20
  );
}

let loaderPromise=null;

export async function loadGoogleMaps(){
  if(window.google?.maps?.importLibrary) return window.google;
  if(!googleMapsConfigured()) throw new Error("Google Maps non configuré");

  if(loaderPromise) return loaderPromise;
  loaderPromise=new Promise((resolve,reject)=>{
    window.__mlayGoogleMapsReady=()=>resolve(window.google);
    const s=document.createElement("script");
    s.src=`https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(GOOGLE_MAPS_API_KEY)}&loading=async&libraries=places&callback=__mlayGoogleMapsReady&language=fr&region=MG`;
    s.async=true;
    s.defer=true;
    s.onerror=()=>reject(new Error("Chargement Google Maps impossible"));
    document.head.appendChild(s);
  });
  return loaderPromise;
}