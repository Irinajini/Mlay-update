# M'lay Service V2 Firebase

## Déjà configuré
- Projet Firebase : `mlay-17f69`
- Realtime Database : `https://mlay-17f69-default-rtdb.europe-west1.firebasedatabase.app`
- Auth : e-mail/mot de passe + Google
- Firebase JS SDK CDN : 12.17.1
- GitHub Pages workflow inclus
- OpenStreetMap + Leaflet pour la carte
- Paiement : à la livraison uniquement

## À faire avant déploiement
1. Ouvrir `firebase-config.js`.
2. Remplacer :
   `REMPLACE_ICI_PAR_TA_VRAIE_API_KEY_FIREBASE`
   par la vraie clé Web API de ton projet Firebase.
3. Dans Firebase Authentication > Settings > Authorized domains, ajouter le domaine GitHub Pages si nécessaire.
4. Dans Realtime Database > Rules, copier le contenu de `database.rules.json` et publier.
5. Pour créer ton premier admin :
   - créer d'abord le compte normalement sur le site ;
   - récupérer son UID dans Firebase Authentication ;
   - dans Realtime Database > `users/{UID}/role`, remplacer `client` par `admin`.
6. Upload le ZIP dans GitHub puis lancer `.github/workflows/deploy-pages.yml`.

## Rôles
- `client`
- `driver`
- `partner`
- `admin`

## Important
Le propriétaire d'un partenaire est lié via `partners/{partnerId}/ownerId = UID`.
Le partenaire peut gérer uniquement ses propres produits et publications.
Le premier livreur qui accepte une course obtient la mission via une transaction Realtime Database.