# M'lay Service V3 — Marketplace & Delivery

Fonctions principales :
- Firebase Authentication + Realtime Database
- Carte Leaflet/OpenStreetMap côté client et livreur
- Boutons Google Maps via Maps URLs sans clé supplémentaire
- Panier, commandes, suivi
- Premier livreur qui accepte = mission attribuée par transaction
- Espace partenaire : CRUD produits/menu + publications + URLs photos
- Admin : commandes, partenaires, menus, publications, publicités, lieux, rôles utilisateurs
- Paiement à la livraison uniquement
- Création automatique des comptes partenaires par admin reportée à une version ultérieure

## Important
Copier `database.rules.json` dans Firebase Realtime Database > Règles puis publier.
Le workflow GitHub Secret de V2.1 est conservé.
