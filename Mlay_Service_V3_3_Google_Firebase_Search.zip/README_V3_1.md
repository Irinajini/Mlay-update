# M'lay Service V3.1 — Responsive + Restaurant Map

## Interface
- Retour à une interface plus compacte inspirée de la V2.
- Mobile : interface application, cartes compactes, navigation fixe en bas.
- PC : dashboard large avec colonne marque et carte latérale persistante.
- Les tailles ne sont plus simplement agrandies sur ordinateur.

## Carte client
- Carte OpenStreetMap/Leaflet sur l'accueil.
- Marqueurs de tous les partenaires qui ont latitude + longitude.
- Clic sur marqueur : nom, catégorie, adresse, Voir le menu, Google Maps.
- Bouton "Ma position".
- Boutons "Voir sur la carte" et "Google Maps" sur chaque restaurant.
- Mini-carte sur la fiche du restaurant.

## Important
Pour afficher un restaurant sur la carte :
Admin → Partenaires → Modifier → renseigner Latitude et Longitude.

Exemple Toliara centre :
Latitude ~ -23.35
Longitude ~ 43.67

Les valeurs exactes doivent être celles du restaurant réel.

## Déploiement
Le système Firebase/GitHub Secret V2.1 reste conservé.