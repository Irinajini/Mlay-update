# M'lay Service V2.1 — Firebase + GitHub Secret

Cette version corrige le problème `auth/api-key-not-valid`.

## Ce qui change
- Aucune clé Firebase n'est stockée en dur dans le ZIP.
- `firebase-config.js` contient un placeholder.
- Le workflow GitHub injecte automatiquement le secret `FIREBASE_API_KEY`.
- Le workflow bloque le déploiement si la clé :
  - est absente ;
  - ne commence pas par `AIza` ;
  - semble tronquée.
- Le workflow vérifie aussi le `projectId` et la `databaseURL`.

## Avant de lancer le workflow
Dans GitHub :

Settings
→ Secrets and variables
→ Actions
→ Repository secrets

Créer ou mettre à jour :

FIREBASE_API_KEY

Puis coller uniquement la valeur complète de `apiKey` copiée directement depuis Firebase Console.

## Important
Pour éviter que GitHub sélectionne un ancien ZIP :
- garde idéalement un seul ZIP M'lay à la racine du dépôt ;
- ou assure-toi que ce ZIP V2.1 est le plus récent.

## Firebase
Projet : mlay-17f69
Realtime Database :
https://mlay-17f69-default-rtdb.europe-west1.firebasedatabase.app

## Déploiement
Actions
→ Deploy Mlay Service V2.1
→ Run workflow
→ main
→ Run workflow

Dans les logs, l'étape `Inject Firebase API key` doit afficher :
- `Firebase API key injectée correctement.`
- une longueur supérieure à 35.
