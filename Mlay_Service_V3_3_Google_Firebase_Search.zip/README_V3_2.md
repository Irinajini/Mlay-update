# M'lay Service V3.2

Corrections principales :
- Toliara comme centre par défaut de toutes les cartes.
- Menus visibles directement sur l'accueil.
- Bouton "Voir les menus".
- Panier visible sur mobile, fiche restaurant et PC.
- Ajout direct au panier depuis l'accueil.
- Vrai espace publicitaire.
- Publicités créées par l'admin affichées dans un carrousel.
- Fallback "Votre publicité ici" si aucune publicité n'existe.
- Carte restaurants toujours présente sur mobile et PC.