@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Déploiement M'LAY Service vers Firebase

echo.
echo ==============================================
echo   M'LAY SERVICE - DEPLOIEMENT FIREBASE
echo   Destination : https://mlayservice601.web.app
echo ==============================================
echo.

where npx >nul 2>&1
if errorlevel 1 (
  echo [ERREUR] Node.js n'est pas installé sur ce PC.
  echo Installe Node.js puis relance ce fichier.
  echo https://nodejs.org/
  pause
  exit /b 1
)

echo [1/3] Vérification de la connexion Firebase...
call npx --yes firebase-tools@latest login:list >nul 2>&1
if errorlevel 1 (
  echo [2/3] Connexion à Firebase...
  call npx --yes firebase-tools@latest login
  if errorlevel 1 goto :error
) else (
  echo [2/3] Compte Firebase déjà connecté.
)

echo [3/3] Déploiement vers mlayservice601.web.app...
call npx --yes firebase-tools@latest deploy --only hosting:mlayservice
if errorlevel 1 goto :error

echo.
echo ==============================================
echo   DEPLOIEMENT TERMINE
echo ==============================================
echo Ouvre : https://mlayservice601.web.app
start "" "https://mlayservice601.web.app"
pause
exit /b 0

:error
echo.
echo Le déploiement a échoué. Aucun fichier local n'a été supprimé.
pause
exit /b 1
