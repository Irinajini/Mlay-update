# M'LAY Service V4 — prêt pour Firebase Hosting

Cette archive est préconfigurée pour :

- Projet Firebase : `mlay-17f69`
- Site Hosting : `mlayservice601`
- Adresse publique : `https://mlayservice601.web.app`

## Déploiement simplifié sur Windows

1. Décompresse le ZIP.
2. Double-clique sur `deploy-firebase.bat`.
3. Lors du premier lancement seulement, Firebase peut ouvrir le navigateur pour te demander de te connecter à ton compte Google.
4. Le script déploie ensuite directement vers `https://mlayservice601.web.app`.

Aucune commande `firebase init` ou `firebase target:apply` n'est nécessaire : les fichiers `firebase.json` et `.firebaserc` sont déjà configurés.

## Connexion Google

Le fichier `firebase-config.js` utilise maintenant `mlayservice601.web.app` comme `authDomain`.

Si la connexion Google affiche `auth/unauthorized-domain`, ajoute `mlayservice601.web.app` dans Firebase Console > Authentication > Settings > Authorized domains.

## Important

Modifier un ZIP ne peut pas publier le site tout seul. Firebase doit recevoir une publication authentifiée au moins une fois. Le fichier `deploy-firebase.bat` automatise cette étape autant que possible.
