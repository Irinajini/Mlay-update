import { auth, db, googleProvider, firebaseConfig } from "./firebase-config.js";
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithPopup,
  signOut, onAuthStateChanged, sendPasswordResetEmail, updateProfile
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";
import {
  ref, set, get, push, update, remove, onValue, query, orderByChild, equalTo,
  runTransaction, serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-database.js";

const STATUS = ["Recherche de livreur","Livreur attribué","En préparation","En route","Livrée","Annulée"];
const state = {
  firebaseUser:null, profile:null, cart:[], address:null, activeMerchant:null,
  activeOrder:null, partners:{}, products:{}, posts:{}, orders:{}, places:{}, ads:{},
  category:"Tous", adminTab:"orders"
};
let unsubs=[];
let addressMap=null, trackingMap=null, addressMarker=null;

const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat("fr-FR").format(Number(n||0))+" Ar";
function toast(msg){ const el=$("toast"); if(!el)return; el.textContent=msg; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2400); }
function initials(name="M"){return name.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join("").toUpperCase();}
function currentRole(){return state.profile?.role||"client";}
function configured(){return firebaseConfig.apiKey && !firebaseConfig.apiKey.includes("REMPLACE_ICI");}

function go(name){
  if(!state.firebaseUser && !["splash","auth"].includes(name)) name="auth";
  if(name==="admin" && currentRole()!=="admin") name="profile";
  if(name==="partner" && currentRole()!=="partner") name="profile";
  if(name==="driver" && currentRole()!=="driver") name="profile";
  document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.dataset.screen===name));
  const active=document.querySelector(`.screen[data-screen="${name}"]`); if(active)active.scrollTop=0;
  if(name==="home")renderHome();
  if(name==="merchant")renderMerchant();
  if(name==="cart")renderCart();
  if(name==="address")setTimeout(initAddressMap,150);
  if(name==="checkout")renderCheckout();
  if(name==="orders")renderOrders();
  if(name==="tracking"){renderTracking();setTimeout(initTrackingMap,150);}
  if(name==="profile")renderProfile();
  if(name==="driver")renderDriver();
  if(name==="partner")renderPartner();
  if(name==="admin")renderAdmin();
}
document.addEventListener("click",e=>{const x=e.target.closest("[data-go]");if(x){e.preventDefault();go(x.dataset.go);}});

function openModal(title,html){
  $("modalTitle").textContent=title; $("modalBody").innerHTML=html; $("modal").classList.remove("hidden");
}
function closeModal(){$("modal").classList.add("hidden");}
$("modalClose").onclick=closeModal;
$("modal").addEventListener("click",e=>{if(e.target===$("modal"))closeModal();});

function normalize(obj){return obj?Object.fromEntries(Object.entries(obj).filter(([,v])=>v!==undefined)):obj;}

async function ensureProfile(user, extra={}){
  const ur=ref(db,`users/${user.uid}`);
  const snap=await get(ur);
  if(!snap.exists()){
    await set(ur,normalize({
      uid:user.uid,name:extra.name||user.displayName||"Utilisateur",
      email:user.email||extra.email||"",phone:extra.phone||"",
      role:"client",status:"active",photoURL:user.photoURL||"",createdAt:Date.now()
    }));
  }
  const fresh=await get(ur); state.profile=fresh.val();
}
async function routeByRole(){
  const r=currentRole();
  go(r==="admin"?"admin":r==="driver"?"driver":r==="partner"?"partner":"home");
}

document.querySelectorAll("[data-auth-tab]").forEach(b=>b.addEventListener("click",()=>{
  const login=b.dataset.authTab==="login";
  document.querySelectorAll("[data-auth-tab]").forEach(x=>x.classList.toggle("active",x===b));
  $("loginForm").classList.toggle("hidden",!login); $("registerForm").classList.toggle("hidden",login);
}));

$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!configured()) return toast("Ajoute d’abord ta vraie apiKey dans firebase-config.js");
  try{
    await signInWithEmailAndPassword(auth,$("loginId").value.trim(),$("loginPassword").value);
  }catch(err){toast("Connexion impossible : "+friendly(err));}
});
$("registerForm").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!configured()) return toast("Ajoute d’abord ta vraie apiKey dans firebase-config.js");
  try{
    const cred=await createUserWithEmailAndPassword(auth,$("regEmail").value.trim(),$("regPassword").value);
    await updateProfile(cred.user,{displayName:$("regName").value.trim()});
    await ensureProfile(cred.user,{name:$("regName").value.trim(),phone:$("regPhone").value.trim()});
    toast("Compte créé"); await routeByRole();
  }catch(err){toast("Inscription impossible : "+friendly(err));}
});
$("googleLoginBtn").onclick=async()=>{
  if(!configured()) return toast("Ajoute d’abord ta vraie apiKey dans firebase-config.js");
  try{
    const cred=await signInWithPopup(auth,googleProvider);
    await ensureProfile(cred.user);
    await routeByRole();
  }catch(err){toast("Connexion Google impossible : "+friendly(err));}
};
$("forgotPasswordBtn").onclick=async()=>{
  const email=$("loginId").value.trim();
  if(!email)return toast("Entre ton e-mail d’abord");
  try{await sendPasswordResetEmail(auth,email);toast("E-mail de réinitialisation envoyé");}
  catch(err){toast("Impossible d’envoyer l’e-mail");}
};
$("logoutBtn").onclick=()=>signOut(auth);
document.querySelector('[data-action="start"]').onclick=()=>go(state.firebaseUser?"home":"auth");

function friendly(err){
  const c=err?.code||"";
  if(c.includes("invalid-credential"))return "e-mail ou mot de passe incorrect";
  if(c.includes("email-already-in-use"))return "cet e-mail est déjà utilisé";
  if(c.includes("weak-password"))return "mot de passe trop faible";
  if(c.includes("popup-closed"))return "fenêtre Google fermée";
  return err?.message||"erreur";
}

function listenData(){
  unsubs.forEach(fn=>fn&&fn()); unsubs=[];
  const listen=(path,key)=>unsubs.push(onValue(ref(db,path),s=>{state[key]=s.val()||{}; rerender();}));
  listen("partners","partners");listen("products","products");listen("posts","posts");
  listen("orders","orders");listen("places","places");listen("ads","ads");
}
function rerender(){
  const active=document.querySelector(".screen.active")?.dataset.screen;
  if(active==="home")renderHome();
  if(active==="merchant")renderMerchant();
  if(active==="orders")renderOrders();
  if(active==="tracking")renderTracking();
  if(active==="driver")renderDriver();
  if(active==="partner")renderPartner();
  if(active==="admin")renderAdmin();
}

onAuthStateChanged(auth,async user=>{
  state.firebaseUser=user;
  if(!user){state.profile=null;go("auth");return;}
  try{
    await ensureProfile(user);
    listenData();
    const active=document.querySelector(".screen.active")?.dataset.screen;
    if(active==="auth"||active==="splash") await routeByRole(); else rerender();
  }catch(err){console.error(err);toast("Erreur de chargement du profil");}
});

function partnerArray(){
  const arr=Object.entries(state.partners||{}).map(([id,v])=>({id,...v}));
  return arr.filter(p=>p.status!=="suspended");
}
function productsFor(partnerId){
  const x=state.products?.[partnerId]||{};
  return Object.entries(x).map(([id,v])=>({id,...v})).filter(p=>p.available!==false);
}
function renderHome(){
  $("homeAvatar").textContent=initials(state.profile?.name);
  const cats=["Tous",...new Set(partnerArray().map(p=>p.category).filter(Boolean))];
  $("categoryRow").innerHTML=cats.map(c=>`<button class="${state.category===c?"active":""}" data-cat="${c}">${c}</button>`).join("");
  $("categoryRow").querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{state.category=b.dataset.cat;renderHome();});
  const q=($("searchInput").value||"").toLowerCase();
  const arr=partnerArray().filter(p=>(state.category==="Tous"||p.category===state.category)&&(!q||`${p.name} ${p.category}`.toLowerCase().includes(q)));
  $("partnerCount").textContent=`${arr.length} partenaire${arr.length>1?"s":""}`;
  $("partnerList").innerHTML=arr.length?arr.map(p=>`<button class="partner-card" data-partner="${p.id}"><span class="partner-icon">${p.icon||"🏪"}</span><div><h4>${p.name}</h4><p>${p.category||"Commerce"} · ${p.address||"Toliara"}</p></div><span class="arrow">›</span></button>`).join(""):'<div class="empty">Aucun partenaire disponible.</div>';
  document.querySelectorAll("[data-partner]").forEach(b=>b.onclick=()=>{state.activeMerchant=b.dataset.partner;go("merchant");});
  updateBadges();
}
$("searchInput").addEventListener("input",renderHome);

function activePartner(){return state.partners?.[state.activeMerchant]||null;}
function renderMerchant(){
  const p=activePartner(); if(!p)return;
  $("merchantName").textContent=p.name;$("merchantHeroName").textContent=p.name;
  $("merchantCategory").textContent=p.category||"Partenaire";$("merchantMeta").textContent=p.address||"Toliara";
  const prods=productsFor(state.activeMerchant);
  $("productList").innerHTML=prods.length?prods.map(x=>`<div class="product-card">${x.imageUrl?`<img class="product-photo" src="${escapeHtml(x.imageUrl)}" alt="">`:`<span class="product-icon">${x.icon||"🍽️"}</span>`}<div><h4>${escapeHtml(x.name)}</h4><p>${money(x.price)}</p></div><button class="add-btn" data-add="${x.id}">Ajouter</button></div>`).join(""):'<div class="empty">Aucun produit publié.</div>';
  document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>addToCart(state.activeMerchant,b.dataset.add));
}
function addToCart(partnerId,id){
  const p=(state.products?.[partnerId]||{})[id];if(!p)return;
  const row=state.cart.find(x=>x.productId===id&&x.partnerId===partnerId);
  if(row)row.qty++;else state.cart.push({partnerId,productId:id,name:p.name,price:Number(p.price||0),qty:1});
  toast("Ajouté au panier");updateBadges();
}
function updateBadges(){const n=state.cart.reduce((s,x)=>s+x.qty,0);$("navCartBadge").textContent=n;$("navCartBadge").classList.toggle("hidden",!n);if($("floatingCartText"))$("floatingCartText").textContent=`${n} article${n>1?"s":""}`;}
function totals(){const subtotal=state.cart.reduce((s,x)=>s+x.price*x.qty,0),delivery=subtotal?3500:0;return{subtotal,delivery,total:subtotal+delivery};}
function renderSummary(id){const t=totals();$(id).innerHTML=`<div class="summary-line"><span>Sous-total</span><span>${money(t.subtotal)}</span></div><div class="summary-line"><span>Livraison</span><span>${money(t.delivery)}</span></div><div class="summary-line total"><span>Total</span><span>${money(t.total)}</span></div>`;}
function renderCart(){
  $("checkoutBtn").disabled=!state.cart.length;
  $("cartContent").innerHTML=state.cart.length?state.cart.map(x=>`<div class="cart-row"><div><h4>${escapeHtml(x.name)}</h4><p>${money(x.price)} × ${x.qty}</p></div><div class="qty"><button data-minus="${x.partnerId}|${x.productId}">−</button><b>${x.qty}</b><button data-plus="${x.partnerId}|${x.productId}">+</button></div></div>`).join(""):'<div class="empty">Ton panier est vide.</div>';
  document.querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>qty(b.dataset.minus,-1));
  document.querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>qty(b.dataset.plus,1));
  renderSummary("cartSummary");updateBadges();
}
function qty(key,d){const[pid,id]=key.split("|");const x=state.cart.find(r=>r.partnerId===pid&&r.productId===id);if(!x)return;x.qty+=d;if(x.qty<=0)state.cart=state.cart.filter(r=>r!==x);renderCart();}
$("checkoutBtn").onclick=()=>go(state.cart.length?"address":"cart");

$("addressForm").addEventListener("submit",e=>{
  e.preventDefault();state.address={label:$("addressLabel").value.trim(),text:$("addressText").value.trim(),note:$("addressNote").value.trim(),geo:state.address?.geo||null};go("checkout");
});
$("geoBtn").onclick=()=>{
  if(!navigator.geolocation)return toast("Géolocalisation indisponible");
  navigator.geolocation.getCurrentPosition(pos=>{
    state.address={...(state.address||{}),geo:{lat:pos.coords.latitude,lng:pos.coords.longitude}};
    if(addressMap){addressMap.setView([pos.coords.latitude,pos.coords.longitude],15);if(addressMarker)addressMarker.remove();addressMarker=L.marker([pos.coords.latitude,pos.coords.longitude]).addTo(addressMap);}
    toast("Position enregistrée");
  },()=>toast("Position impossible"));
};
function initAddressMap(){
  if(!window.L||addressMap)return;
  addressMap=L.map("addressMap").setView([-23.35,43.67],13);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"}).addTo(addressMap);
  addressMap.on("click",e=>{state.address={...(state.address||{}),geo:{lat:e.latlng.lat,lng:e.latlng.lng}};if(addressMarker)addressMarker.remove();addressMarker=L.marker(e.latlng).addTo(addressMap);});
}
function renderCheckout(){renderSummary("checkoutRecap");}
$("placeOrderBtn").onclick=async()=>{
  if(!state.address)return toast("Adresse manquante");
  if(!state.cart.length)return toast("Panier vide");
  const key=push(ref(db,"orders")).key; const t=totals();
  const partnerIds=[...new Set(state.cart.map(x=>x.partnerId))];
  await set(ref(db,`orders/${key}`),{
    id:key,clientId:state.firebaseUser.uid,clientName:state.profile?.name||"",
    partnerIds,items:state.cart,address:state.address,total:t.total,deliveryFee:t.delivery,
    paymentMethod:"cash",paymentStatus:"pending",status:"searching_driver",
    driverId:null,createdAt:Date.now()
  });
  state.activeOrder=key;state.cart=[];updateBadges();toast("Commande créée");go("tracking");
};

function orderArray(){return Object.entries(state.orders||{}).map(([id,o])=>({id,...o}));}
function myOrders(){return orderArray().filter(o=>o.clientId===state.firebaseUser?.uid);}
function renderOrders(){
  const arr=myOrders().sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));
  $("ordersList").innerHTML=arr.length?arr.map(o=>`<button class="order-card" data-order="${o.id}"><div class="order-head"><h4>${o.id.slice(-8)}</h4><span class="status-pill">${statusLabel(o.status)}</span></div><p>${new Date(o.createdAt).toLocaleString("fr-FR")}</p><p><b>${money(o.total)}</b></p></button>`).join(""):'<div class="empty">Aucune commande.</div>';
  document.querySelectorAll("[data-order]").forEach(b=>b.onclick=()=>{state.activeOrder=b.dataset.order;go("tracking");});
}
function statusLabel(s){return({searching_driver:"Recherche de livreur",driver_assigned:"Livreur attribué",preparing:"En préparation",on_the_way:"En route",delivered:"Livrée",cancelled:"Annulée"})[s]||s;}
function activeOrder(){return state.orders?.[state.activeOrder]||myOrders()[0]||null;}
function renderTracking(){
  const o=activeOrder();if(!o){$("trackingInfo").innerHTML='<div class="empty">Aucune commande.</div>';$("timeline").innerHTML="";return;}
  $("trackingInfo").innerHTML=`<div class="summary-card"><b>${o.id.slice(-8)}</b><div class="summary-line"><span>Statut</span><span>${statusLabel(o.status)}</span></div><div class="summary-line"><span>Total</span><span>${money(o.total)}</span></div><div class="summary-line"><span>Paiement</span><span>À la livraison</span></div></div>`;
  const steps=["searching_driver","driver_assigned","preparing","on_the_way","delivered"];const idx=Math.max(0,steps.indexOf(o.status));
  $("timeline").innerHTML=steps.map((s,i)=>`<div class="timeline-step ${i<=idx?"done":""}"><i></i><span>${statusLabel(s)}</span></div>`).join("");
}
function initTrackingMap(){
  if(!window.L||trackingMap)return;
  trackingMap=L.map("trackingMap").setView([-23.35,43.67],13);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"© OpenStreetMap"}).addTo(trackingMap);
  const o=activeOrder();if(o?.address?.geo)L.marker([o.address.geo.lat,o.address.geo.lng]).addTo(trackingMap).bindPopup("Destination");
}
if($("advanceDemoBtn"))$("advanceDemoBtn").remove();

function renderProfile(){
  const u=state.profile;if(!u)return;
  $("profileAvatar").textContent=initials(u.name);$("profileName").textContent=u.name||"Utilisateur";$("profileContact").textContent=`${u.email||""} · ${u.phone||""}`;
  const b=$("profileRoleButton");b.classList.toggle("hidden",u.role==="client");
  b.onclick=()=>go(u.role==="admin"?"admin":u.role==="driver"?"driver":"partner");
}

$("driverOnline").onchange=async e=>{
  if(currentRole()!=="driver")return;
  await set(ref(db,`driverStatus/${state.firebaseUser.uid}`),{online:e.target.checked,updatedAt:Date.now()});
  renderDriver();
};
async function claimOrder(orderId){
  const oref=ref(db,`orders/${orderId}`);
  const result=await runTransaction(oref,current=>{
    if(!current || current.driverId || current.status!=="searching_driver") return;
    return {...current,driverId:state.firebaseUser.uid,driverName:state.profile?.name||"",status:"driver_assigned",acceptedAt:Date.now()};
  });
  if(result.committed)toast("Mission acceptée");else toast("Un autre livreur a déjà pris cette livraison");
}
function renderDriver(){
  $("driverName").textContent=state.profile?.name||"Livreur";
  get(ref(db,`driverStatus/${state.firebaseUser.uid}`)).then(s=>{const online=!!s.val()?.online;$("driverOnline").checked=online;$("driverStatus").textContent=online?"🟢 En ligne":"⚪ Hors ligne";});
  const available=orderArray().filter(o=>o.status==="searching_driver"&&!o.driverId).sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));
  $("driverNotifCount").textContent=`${available.length} nouvelle${available.length>1?"s":""}`;
  $("driverMission").innerHTML=available.length?available.slice(0,5).map(o=>`<div class="mission-card"><div class="order-head"><b>Nouvelle livraison</b><span class="mission-price">+ ${money(o.deliveryFee||3500)}</span></div><p>${escapeHtml(o.address?.text||"Adresse client")}</p><button class="btn btn-primary full" data-claim="${o.id}">Accepter</button></div>`).join(""):'<div class="empty">Aucune demande disponible.</div>';
  document.querySelectorAll("[data-claim]").forEach(b=>b.onclick=()=>claimOrder(b.dataset.claim));
  const mine=orderArray().filter(o=>o.driverId===state.firebaseUser.uid);
  const delivered=mine.filter(o=>o.status==="delivered");
  $("driverKpis").innerHTML=`<div class="kpi"><strong>${mine.length}</strong><span>Missions</span></div><div class="kpi"><strong>${delivered.length}</strong><span>Livrées</span></div><div class="kpi"><strong>${money(delivered.reduce((s,o)=>s+(o.deliveryFee||3500),0))}</strong><span>Gains</span></div>`;
  $("driverDeliveries").innerHTML=mine.length?mine.map(o=>`<div class="admin-table-row"><div><b>${o.id.slice(-8)}</b><br><small>${statusLabel(o.status)}</small></div><span>${money(o.deliveryFee||3500)}</span></div>`).join(""):'<p class="muted">Aucune livraison.</p>';
}

function myPartnerEntry(){
  return Object.entries(state.partners||{}).find(([,p])=>p.ownerId===state.firebaseUser?.uid);
}
function renderPartner(){
  const entry=myPartnerEntry();
  if(!entry){$("partnerSpaceName").textContent="Compte partenaire";$("partnerProducts").innerHTML='<div class="empty">Ton compte n’est pas encore lié à un commerce. L’administrateur doit créer/valider ton partenaire.</div>';$("partnerPosts").innerHTML="";return;}
  const [pid,p]=entry;$("partnerSpaceName").textContent=p.name;
  const products=Object.entries(state.products?.[pid]||{}).map(([id,v])=>({id,...v}));
  $("partnerProducts").innerHTML=products.length?products.map(x=>`<div class="admin-table-row"><div><b>${escapeHtml(x.name)}</b><br><small>${money(x.price)} · ${x.available===false?"Indisponible":"Disponible"}</small></div><div><button class="mini-action" data-edit-prod="${pid}|${x.id}">Modifier</button><button class="mini-action danger" data-del-prod="${pid}|${x.id}">Suppr.</button></div></div>`).join(""):'<p class="muted">Aucun produit.</p>';
  document.querySelectorAll("[data-edit-prod]").forEach(b=>b.onclick=()=>productModal(pid,b.dataset.editProd.split("|")[1]));
  document.querySelectorAll("[data-del-prod]").forEach(b=>b.onclick=async()=>{const[a,id]=b.dataset.delProd.split("|");await remove(ref(db,`products/${a}/${id}`));});
  const posts=Object.entries(state.posts||{}).filter(([,v])=>v.partnerId===pid).map(([id,v])=>({id,...v}));
  $("partnerPosts").innerHTML=posts.length?posts.map(x=>`<div class="admin-table-row"><div><b>${escapeHtml(x.title)}</b><br><small>${escapeHtml(x.text||"")}</small></div><button class="mini-action danger" data-del-post="${x.id}">Suppr.</button></div>`).join(""):'<p class="muted">Aucune publication.</p>';
  document.querySelectorAll("[data-del-post]").forEach(b=>b.onclick=()=>remove(ref(db,`posts/${b.dataset.delPost}`)));
  $("addProductBtn").onclick=()=>productModal(pid);
  $("addPostBtn").onclick=()=>postModal(pid);
}
function productModal(pid,id=null){
  const x=id?(state.products?.[pid]||{})[id]:{};
  openModal(id?"Modifier le produit":"Ajouter un produit",`<form id="productForm" class="form-stack"><label>Nom<input id="mProdName" required value="${escapeAttr(x.name||"")}"></label><label>Prix (Ar)<input id="mProdPrice" type="number" min="0" required value="${x.price||""}"></label><label>URL photo<input id="mProdImage" value="${escapeAttr(x.imageUrl||"")}" placeholder="https://..."></label><label><input id="mProdAvailable" type="checkbox" ${x.available===false?"":"checked"}> Disponible</label><button class="btn btn-primary">Enregistrer</button></form>`);
  $("productForm").onsubmit=async e=>{e.preventDefault();const key=id||push(ref(db,`products/${pid}`)).key;await set(ref(db,`products/${pid}/${key}`),{name:$("mProdName").value.trim(),price:Number($("mProdPrice").value),imageUrl:$("mProdImage").value.trim(),available:$("mProdAvailable").checked,updatedAt:Date.now()});closeModal();};
}
function postModal(pid){
  openModal("Nouvelle publication",`<form id="postForm" class="form-stack"><label>Titre<input id="mPostTitle" required></label><label>Texte<textarea id="mPostText" rows="4"></textarea></label><label>URL photo<input id="mPostImage" placeholder="https://..."></label><button class="btn btn-primary">Publier</button></form>`);
  $("postForm").onsubmit=async e=>{e.preventDefault();const key=push(ref(db,"posts")).key;await set(ref(db,`posts/${key}`),{partnerId:pid,ownerId:state.firebaseUser.uid,title:$("mPostTitle").value.trim(),text:$("mPostText").value.trim(),imageUrl:$("mPostImage").value.trim(),createdAt:Date.now()});closeModal();};
}

document.querySelectorAll("[data-admin-tab]").forEach(b=>b.onclick=()=>{state.adminTab=b.dataset.adminTab;document.querySelectorAll("[data-admin-tab]").forEach(x=>x.classList.toggle("active",x===b));renderAdmin();});
function renderAdmin(){
  const orders=orderArray(),usersPromise=get(ref(db,"users"));
  $("adminKpis").innerHTML=`<div class="admin-kpi"><strong>${orders.length}</strong><span>Commandes</span></div><div class="admin-kpi"><strong>${partnerArray().length}</strong><span>Partenaires</span></div><div class="admin-kpi"><strong>${Object.keys(state.places||{}).length}</strong><span>Lieux</span></div><div class="admin-kpi"><strong>${Object.keys(state.ads||{}).length}</strong><span>Pubs</span></div>`;
  if(state.adminTab==="orders"){
    $("adminTabContent").innerHTML='<div class="section-title"><h3>Commandes</h3></div>'+orders.map(o=>`<div class="admin-table-row"><div><b>${o.id.slice(-8)}</b><br><small>${statusLabel(o.status)}</small></div><select data-order-status="${o.id}"><option value="searching_driver">Recherche livreur</option><option value="driver_assigned">Livreur attribué</option><option value="preparing">Préparation</option><option value="on_the_way">En route</option><option value="delivered">Livrée</option><option value="cancelled">Annulée</option></select></div>`).join("");
    document.querySelectorAll("[data-order-status]").forEach(s=>{s.value=state.orders[s.dataset.orderStatus]?.status||"searching_driver";s.onchange=()=>update(ref(db,`orders/${s.dataset.orderStatus}`),{status:s.value});});
  }else if(state.adminTab==="partners"){
    $("adminTabContent").innerHTML='<div class="section-title"><h3>Partenaires</h3><button id="adminAddPartner" class="btn-small">+ Ajouter</button></div>'+Object.entries(state.partners||{}).map(([id,p])=>`<div class="admin-table-row"><div><b>${escapeHtml(p.name)}</b><br><small>${escapeHtml(p.category||"")} · ${p.status||"active"}</small></div><div><button class="mini-action" data-edit-partner="${id}">Modifier</button><button class="mini-action danger" data-del-partner="${id}">Suppr.</button></div></div>`).join("");
    $("adminAddPartner").onclick=()=>partnerModal();
    document.querySelectorAll("[data-edit-partner]").forEach(b=>b.onclick=()=>partnerModal(b.dataset.editPartner));
    document.querySelectorAll("[data-del-partner]").forEach(b=>b.onclick=()=>remove(ref(db,`partners/${b.dataset.delPartner}`)));
  }else if(state.adminTab==="places"){
    renderSimpleAdminList("places","Lieux","Nom du lieu","address");
  }else if(state.adminTab==="ads"){
    renderSimpleAdminList("ads","Publicités","Titre de la publicité","imageUrl");
  }else if(state.adminTab==="users"){
    usersPromise.then(s=>{const users=s.val()||{};$("adminTabContent").innerHTML='<div class="section-title"><h3>Utilisateurs</h3></div>'+Object.entries(users).map(([id,u])=>`<div class="admin-table-row"><div><b>${escapeHtml(u.name||u.email)}</b><br><small>${escapeHtml(u.email||"")}</small></div><select data-user-role="${id}"><option value="client">Client</option><option value="driver">Livreur</option><option value="partner">Partenaire</option><option value="admin">Admin</option></select></div>`).join("");document.querySelectorAll("[data-user-role]").forEach(sel=>{sel.value=users[sel.dataset.userRole].role||"client";sel.onchange=()=>update(ref(db,`users/${sel.dataset.userRole}`),{role:sel.value});});});
  }
}
function partnerModal(id=null){
  const p=id?state.partners[id]:{};
  openModal(id?"Modifier partenaire":"Ajouter partenaire",`<form id="partnerForm" class="form-stack"><label>Nom<input id="mPartnerName" required value="${escapeAttr(p.name||"")}"></label><label>Catégorie<input id="mPartnerCategory" value="${escapeAttr(p.category||"Restaurants")}"></label><label>Adresse<input id="mPartnerAddress" value="${escapeAttr(p.address||"Toliara")}"></label><label>UID propriétaire<input id="mPartnerOwner" value="${escapeAttr(p.ownerId||"")}" placeholder="UID Firebase du partenaire"></label><label>Statut<select id="mPartnerStatus"><option value="active">Actif</option><option value="pending">En attente</option><option value="suspended">Suspendu</option></select></label><button class="btn btn-primary">Enregistrer</button></form>`);
  $("mPartnerStatus").value=p.status||"active";
  $("partnerForm").onsubmit=async e=>{e.preventDefault();const key=id||push(ref(db,"partners")).key;await set(ref(db,`partners/${key}`),{name:$("mPartnerName").value.trim(),category:$("mPartnerCategory").value.trim(),address:$("mPartnerAddress").value.trim(),ownerId:$("mPartnerOwner").value.trim(),status:$("mPartnerStatus").value,updatedAt:Date.now()});closeModal();};
}
function renderSimpleAdminList(path,title,label,secondary){
  const data=state[path]||{};
  $("adminTabContent").innerHTML=`<div class="section-title"><h3>${title}</h3><button id="simpleAdd" class="btn-small">+ Ajouter</button></div>`+Object.entries(data).map(([id,v])=>`<div class="admin-table-row"><div><b>${escapeHtml(v.name||v.title||"Élément")}</b><br><small>${escapeHtml(v[secondary]||"")}</small></div><button class="mini-action danger" data-simple-del="${id}">Suppr.</button></div>`).join("");
  $("simpleAdd").onclick=()=>{openModal("Ajouter",`<form id="simpleForm" class="form-stack"><label>${label}<input id="simpleName" required></label><label>${secondary==="imageUrl"?"URL image":"Adresse / détail"}<input id="simpleSecondary"></label><button class="btn btn-primary">Enregistrer</button></form>`);$("simpleForm").onsubmit=async e=>{e.preventDefault();const key=push(ref(db,path)).key;const obj=secondary==="imageUrl"?{title:$("simpleName").value.trim(),imageUrl:$("simpleSecondary").value.trim(),active:true}:{name:$("simpleName").value.trim(),address:$("simpleSecondary").value.trim(),active:true};await set(ref(db,`${path}/${key}`),obj);closeModal();};};
  document.querySelectorAll("[data-simple-del]").forEach(b=>b.onclick=()=>remove(ref(db,`${path}/${b.dataset.simpleDel}`)));
}
function escapeHtml(v=""){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function escapeAttr(v=""){return escapeHtml(v);}

updateBadges();